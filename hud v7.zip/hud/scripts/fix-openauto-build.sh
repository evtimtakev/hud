#!/bin/bash

# OpenAuto Build Fix Script
# Fixes common OpenAuto compilation issues including missing AASDK headers

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}    Android Auto HUD - OpenAuto Build Fix${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

print_header

# Check available memory
MEMORY_GB=$(free -g | awk '/^Mem:/{print $2}')
print_status "Available memory: ${MEMORY_GB}GB"

if [ "$MEMORY_GB" -lt 3 ]; then
    print_warning "Less than 4GB RAM detected. OpenAuto compilation may fail."
    print_status "Consider increasing swap space or using the simple interface."
    read -p "Continue with OpenAuto build anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        print_status "Use './scripts/quick-setup.sh' for a lightweight alternative"
        exit 0
    fi
fi

# Navigate to the project directory
cd /opt/android-auto-hud || {
    print_error "Project directory /opt/android-auto-hud not found"
    print_status "Run the main installation script first: sudo ./install.sh"
    exit 1
}

# Clean previous failed builds
if [ -d "openauto" ]; then
    print_status "Removing previous OpenAuto installation..."
    rm -rf openauto
fi

# Install/verify all required dependencies
print_status "Installing OpenAuto build dependencies..."

# Core build tools
apt update
apt install -y \
    git \
    cmake \
    build-essential \
    pkg-config \
    ninja-build

# Qt5 dependencies with error handling
install_packages_safe() {
    local packages=("$@")
    local failed_packages=()
    
    for package in "${packages[@]}"; do
        print_status "Installing $package..."
        if ! apt install -y "$package" 2>/dev/null; then
            print_warning "Failed to install $package"
            failed_packages+=("$package")
        fi
    done
    
    if [ ${#failed_packages[@]} -gt 0 ]; then
        print_warning "Some packages failed: ${failed_packages[*]}"
        return 1
    fi
    return 0
}

# Qt5 packages
QT5_PACKAGES=(
    "qt5-qmake"
    "qtbase5-dev"
    "qtbase5-dev-tools" 
    "qtdeclarative5-dev"
    "qtquickcontrols2-5-dev"
    "qtmultimedia5-dev"
    "qtconnectivity5-dev"
    "libqt5multimedia5-plugins"
    "libqt5webchannel5-dev"
    "libqt5widgets5"
    "libqt5core5a"
    "libqt5quick5"
    "libqt5quickwidgets5"
    "libqt5qml5"
    "libqt5network5"
    "libqt5gui5"
    "libqt5dbus5"
    "libqt5xml5"
    "libqt5opengl5-dev"
    "qml-module-qtquick2"
    "qml-module-qtquick-controls"
    "qml-module-qtquick-controls2"
)

print_status "Installing Qt5 packages..."
install_packages_safe "${QT5_PACKAGES[@]}"

# System libraries for OpenAuto
SYSTEM_PACKAGES=(
    "libboost-all-dev"
    "libssl-dev"
    "libprotobuf-dev"
    "protobuf-compiler"
    "libusb-1.0-0-dev"
    "libtag1-dev"
    "librtaudio-dev"
    "libasound2-dev"
    "libpulse-dev"
    "libsbc-dev"
    "libspeexdsp-dev"
)

print_status "Installing system libraries..."
install_packages_safe "${SYSTEM_PACKAGES[@]}"

# GStreamer development packages
GSTREAMER_PACKAGES=(
    "libgstreamer1.0-dev"
    "libgstreamer-plugins-base1.0-dev"
    "libgstreamer-plugins-good1.0-dev"
    "libgstreamer-plugins-bad1.0-dev"
    "gstreamer1.0-plugins-base"
    "gstreamer1.0-plugins-good" 
    "gstreamer1.0-plugins-bad"
    "gstreamer1.0-plugins-ugly"
    "gstreamer1.0-libav"
    "gstreamer1.0-tools"
)

print_status "Installing GStreamer packages..."
install_packages_safe "${GSTREAMER_PACKAGES[@]}"

# Increase swap space temporarily for compilation
print_status "Configuring swap space for compilation..."
CURRENT_SWAP=$(swapon --show=SIZE --noheadings --bytes | head -1)
if [ -z "$CURRENT_SWAP" ] || [ "$CURRENT_SWAP" -lt 1073741824 ]; then  # Less than 1GB
    print_status "Increasing swap space to 2GB for compilation..."
    
    # Create temporary swap file
    fallocate -l 2G /tmp/compilation_swap || dd if=/dev/zero of=/tmp/compilation_swap bs=1M count=2048
    chmod 600 /tmp/compilation_swap
    mkswap /tmp/compilation_swap
    swapon /tmp/compilation_swap
    
    CLEANUP_SWAP=true
else
    CLEANUP_SWAP=false
fi

# Clone OpenAuto with proper error handling
print_status "Cloning OpenAuto repository..."
if ! git clone --recursive --depth 1 https://github.com/f1xpl/openauto.git; then
    print_error "Failed to clone OpenAuto repository"
    print_status "Checking internet connection and trying alternative..."
    
    # Try without --recursive first
    if git clone --depth 1 https://github.com/f1xpl/openauto.git; then
        cd openauto
        print_status "Manually initializing submodules..."
        git submodule update --init --recursive --depth 1
    else
        print_error "Cannot clone OpenAuto repository"
        exit 1
    fi
else
    cd openauto
fi

# Verify and fix AASDK submodule
print_status "Verifying AASDK submodule..."
if [ ! -d "aasdk" ] || [ ! -f "aasdk/include/f1x/aasdk/IOPromise.hpp" ]; then
    print_warning "AASDK submodule incomplete, fixing..."
    
    # Remove and re-clone AASDK
    rm -rf aasdk
    if ! git clone https://github.com/f1xpl/aasdk.git; then
        print_error "Failed to clone AASDK manually"
        exit 1
    fi
    
    # Verify the critical header file exists
    if [ ! -f "aasdk/include/f1x/aasdk/IOPromise.hpp" ]; then
        print_error "Critical AASDK header file still missing"
        ls -la aasdk/include/f1x/aasdk/ || echo "AASDK include directory not found"
        exit 1
    fi
fi

print_success "AASDK submodule verified"

# Build AASDK first
print_status "Building AASDK library..."
cd aasdk
mkdir -p build
cd build

if cmake \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CXX_STANDARD=14 \
    ../; then
    
    if make -j$(nproc --ignore=1); then
        print_success "AASDK built successfully"
    else
        print_error "AASDK build failed"
        exit 1
    fi
else
    print_error "AASDK CMake configuration failed"
    exit 1
fi

# Return to OpenAuto directory
cd ../../

# Build OpenAuto
print_status "Building OpenAuto..."
mkdir -p build
cd build

# Configure OpenAuto build with proper AASDK library paths
print_status "Configuring OpenAuto build..."
AASDK_BUILD_PATH="$(pwd)/../aasdk/build"
AASDK_LIB_PATH="$AASDK_BUILD_PATH/lib"

# Check if AASDK library exists
if [ ! -f "$AASDK_BUILD_PATH/libaasdk.a" ] && [ ! -f "$AASDK_LIB_PATH/libaasdk.a" ]; then
    print_error "AASDK library not found. Expected at $AASDK_BUILD_PATH/libaasdk.a"
    print_status "Contents of AASDK build directory:"
    ls -la "$AASDK_BUILD_PATH" || echo "Build directory not found"
    find "$AASDK_BUILD_PATH" -name "*aasdk*" 2>/dev/null || echo "No AASDK libraries found"
    exit 1
fi

if cmake \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CXX_STANDARD=14 \
    -DRPI_BUILD=TRUE \
    -DAASDK_INCLUDE_DIRS="$(pwd)/../aasdk/include" \
    -DAASDK_LIBRARIES="$AASDK_BUILD_PATH" \
    -DAASDK_PROTO_INCLUDE_DIRS="$(pwd)/../aasdk" \
    -DAASDK_PROTO_LIBRARIES="$AASDK_BUILD_PATH" \
    -DGST_BUILD=TRUE \
    -DQT_BUILD=TRUE \
    -DUSE_GST=TRUE \
    -G Ninja \
    ../; then
    
    print_status "Building OpenAuto (this may take 20-40 minutes)..."
    if ninja -j$(nproc --ignore=1); then
        print_status "Installing OpenAuto..."
        if ninja install; then
            print_success "OpenAuto installed successfully!"
        else
            print_warning "OpenAuto install failed, but build succeeded"
        fi
    else
        print_error "OpenAuto build failed"
        
        # Show build log for debugging
        print_status "Build error details:"
        cat build.ninja.log 2>/dev/null || echo "No build log available"
        
        exit 1
    fi
else
    print_error "OpenAuto CMake configuration failed"
    
    # Show CMake error details
    print_status "CMake error details:"
    cat CMakeFiles/CMakeError.log 2>/dev/null || echo "No CMake error log available"
    
    exit 1
fi

# Clean up temporary swap if we created it
if [ "$CLEANUP_SWAP" = true ]; then
    print_status "Cleaning up temporary swap space..."
    swapoff /tmp/compilation_swap
    rm -f /tmp/compilation_swap
fi

# Verify installation
print_status "Verifying OpenAuto installation..."
if [ -f "bin/autoapp" ]; then
    print_success "OpenAuto binary found: $(pwd)/bin/autoapp"
    
    # Test if it can load
    if ldd bin/autoapp > /dev/null 2>&1; then
        print_success "OpenAuto dependencies satisfied"
    else
        print_warning "OpenAuto may have dependency issues"
        ldd bin/autoapp
    fi
else
    print_error "OpenAuto binary not found after build"
    ls -la bin/ || echo "No bin directory"
    exit 1
fi

# Update startup script to use the correct path
print_status "Updating startup script..."
AUTOAPP_PATH="$(pwd)/bin/autoapp"
sed -i "s|/opt/android-auto-hud/openauto/build/bin/autoapp|$AUTOAPP_PATH|g" /opt/android-auto-hud/start-hud.sh

# Set proper permissions
print_status "Setting permissions..."
chown -R pi:pi /opt/android-auto-hud/openauto
chmod +x "$AUTOAPP_PATH"

print_success "OpenAuto build fix completed!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_status "OpenAuto is now installed and ready to use"
echo ""
echo "To test OpenAuto:"
echo "  sudo systemctl restart android-auto-hud"
echo "  sudo ./scripts/android-auto-service.sh status"
echo ""
echo "To view logs:"
echo "  sudo ./scripts/android-auto-service.sh logs"
echo ""
echo "OpenAuto binary location: $AUTOAPP_PATH"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" 