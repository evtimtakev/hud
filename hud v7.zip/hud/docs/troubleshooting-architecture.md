# Architecture Troubleshooting Guide

## Problem: "Unsupported architecture i386 only amd64 arm64" Error

This error occurs when the package manager tries to install packages for the wrong architecture. Raspberry Pi systems use ARM architecture (arm64 or armhf), but sometimes packages try to install for i386 (32-bit x86) which is incompatible.

## Common Causes

1. **Foreign Architecture Configuration**: The system has i386 architecture enabled as a foreign architecture
2. **Repository Mismatch**: Package repositories are configured for the wrong architecture
3. **Node.js Repository Issues**: Third-party repositories (like NodeSource) may have architecture conflicts
4. **Package Cache Corruption**: Cached package information contains wrong architecture data

## Quick Fix

Run the architecture fix script:

```bash
sudo ./scripts/fix-architecture.sh
```

This script will:
- Detect your system architecture
- Remove problematic foreign architectures (especially i386)
- Clean package caches
- Set proper architecture preferences
- Test package installation

## Manual Fix Steps

If the automated script doesn't work, follow these manual steps:

### 1. Check Current Architecture

```bash
# Check primary architecture
dpkg --print-architecture

# Check foreign architectures
dpkg --print-foreign-architectures

# Check system info
uname -m
lsb_release -a
```

Expected output for Raspberry Pi 5:
- Primary architecture: `arm64`
- System: `aarch64`
- No foreign architectures (or only `armhf`)

### 2. Remove Problematic Architectures

```bash
# Remove i386 architecture if present
sudo dpkg --remove-architecture i386

# Check it's gone
dpkg --print-foreign-architectures
```

### 3. Clean Package System

```bash
# Clean all caches
sudo apt clean
sudo apt autoclean
sudo rm -rf /var/lib/apt/lists/*

# Update package database
sudo apt update
```

### 4. Set Architecture Preferences

Create `/etc/apt/preferences.d/99-raspberry-pi-architecture`:

```bash
sudo tee /etc/apt/preferences.d/99-raspberry-pi-architecture << EOF
Package: *
Pin: version *
Pin-Priority: 100

Package: *
Pin: release a=* l=* c=* origin=* architecture=arm64
Pin-Priority: 500
EOF
```

Replace `arm64` with `armhf` if your system uses armhf architecture.

### 5. Check Repository Sources

```bash
# Check for architecture-specific issues in sources
grep -r "i386" /etc/apt/sources.list /etc/apt/sources.list.d/ || echo "No i386 references found"

# Remove problematic Node.js repository if present
sudo rm -f /etc/apt/sources.list.d/nodesource.list
```

### 6. Test Package Installation

```bash
# Test with a simple package
sudo apt install -y --dry-run wget

# If successful, test Qt5 packages
apt-cache policy qt5-qmake qtbase5-dev
```

## Package-Specific Solutions

### Qt5 Packages

If Qt5 packages fail:

```bash
# For newer Raspberry Pi OS (Bookworm/Bullseye)
sudo apt install -y qt5-qmake qtbase5-dev qtbase5-dev-tools

# For older versions
sudo apt install -y qt5-default
```

### Node.js Issues

Instead of using NodeSource repository:

```bash
# Use system packages
sudo apt install -y nodejs npm

# Or use snap
sudo snap install node --classic
```

### GStreamer and Media Libraries

```bash
# Install with specific architecture checking
sudo apt install -y gstreamer1.0-tools gstreamer1.0-plugins-base
```

## Advanced Diagnostics

### Check Available Packages

```bash
# Check what architectures a package supports
apt-cache policy <package-name>

# List all available architectures for a package
apt-cache madison <package-name>
```

### Verify Repository Architecture

```bash
# Check repository architecture support
grep -r "Architectures:" /var/lib/apt/lists/
```

### System Architecture Verification

```bash
# Comprehensive system check
echo "CPU Info:"
cat /proc/cpuinfo | grep -E "(processor|model|Hardware|Revision)"

echo -e "\nArchitecture Info:"
dpkg --print-architecture
dpkg --print-foreign-architectures
uname -a

echo -e "\nOS Info:"
lsb_release -a
```

## Prevention

To prevent future architecture issues:

1. **Avoid Adding i386 Architecture**: Don't run `dpkg --add-architecture i386` on ARM systems
2. **Use System Packages**: Prefer system packages over third-party repositories when possible
3. **Check Before Installing**: Verify package architecture before installation
4. **Regular Maintenance**: Periodically clean package caches and check for conflicts

## Still Having Issues?

If architecture problems persist:

1. **Full System Update**: `sudo apt update && sudo apt full-upgrade`
2. **Check Disk Space**: Ensure sufficient space in `/tmp` and `/var`
3. **Memory Check**: Verify sufficient RAM (4GB+ recommended for compilation)
4. **Alternative Installation**: Try the quick-setup script instead: `sudo ./scripts/quick-setup.sh`

## Error Examples and Solutions

### "Package has no installation candidate"
- **Cause**: Package not available for your architecture
- **Solution**: Find architecture-compatible alternative or use different repository

### "Depends: package:i386 but it is not installable"
- **Cause**: System trying to install 32-bit x86 dependencies
- **Solution**: Remove i386 architecture and clean package cache

### "Unable to locate package"
- **Cause**: Repository not configured for ARM architecture
- **Solution**: Use system repositories instead of third-party ones

### "Unmet dependencies"
- **Cause**: Architecture mismatch in dependency chain
- **Solution**: Install packages individually or use architecture-specific versions

---

**Last Updated**: $(date)
**Tested On**: Raspberry Pi 5, Raspberry Pi OS Bookworm (arm64) 