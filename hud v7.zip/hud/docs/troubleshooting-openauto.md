# OpenAuto Build Troubleshooting

## Problem: "fatal error: f1x/aasdk/IOPromise.hpp: No such file or directory"

This error occurs when the AASDK (Android Auto SDK) submodule is missing or incomplete during OpenAuto compilation.

## Problem: "/usr/bin/ld: cannot find -l .../aasdk"

This linker error occurs when the OpenAuto build cannot find the AASDK library file, usually because:
- AASDK library wasn't built properly
- Library paths are incorrect in CMake configuration
- Library file is in an unexpected location

## Problem: "Promise.hpp:35: expected class-name before '{' token"

This C++ syntax error occurs when there are compatibility issues between different C++ standards or compiler versions:
- C++14/17 syntax incompatibilities
- Missing base class specifications
- Compiler version conflicts
- Boost library version mismatches

## Common Causes

1. **Incomplete Git Clone**: The `--recursive` flag wasn't used or submodules failed to download
2. **Network Issues**: Internet connection problems during submodule download
3. **Missing Dependencies**: Required build tools or libraries not installed
4. **Memory Issues**: Insufficient RAM/swap space for compilation
5. **Corrupted Submodules**: Partially downloaded or corrupted AASDK files

## Quick Fix

### For IOPromise.hpp errors:
Use the dedicated OpenAuto build fix script:

```bash
sudo ./scripts/fix-openauto-build.sh
```

### For AASDK linker errors:
Use the dedicated AASDK linker fix script:

```bash
sudo ./scripts/fix-aasdk-linker.sh
```

### For C++ syntax errors:
Use the dedicated C++ syntax fix script:

```bash
sudo ./scripts/fix-cpp-syntax.sh
```

This script will:
- Clean previous failed builds
- Install all required dependencies
- Properly clone OpenAuto with submodules
- Verify AASDK is complete
- Build AASDK first, then OpenAuto
- Handle memory/swap issues
- Provide detailed error reporting

## Manual Fix Steps

If the automated script doesn't work, follow these steps:

### 1. Clean Previous Attempts

```bash
sudo rm -rf /opt/android-auto-hud/openauto
cd /opt/android-auto-hud
```

### 2. Install Required Dependencies

```bash
# Core build tools
sudo apt update
sudo apt install -y \
    git \
    cmake \
    build-essential \
    pkg-config \
    ninja-build

# Qt5 development packages
sudo apt install -y \
    qt5-qmake \
    qtbase5-dev \
    qtbase5-dev-tools \
    qtdeclarative5-dev \
    qtquickcontrols2-5-dev \
    qtmultimedia5-dev \
    qtconnectivity5-dev

# System libraries
sudo apt install -y \
    libboost-all-dev \
    libssl-dev \
    libprotobuf-dev \
    protobuf-compiler \
    libusb-1.0-0-dev \
    libtag1-dev \
    librtaudio-dev \
    libasound2-dev \
    libpulse-dev

# GStreamer development
sudo apt install -y \
    libgstreamer1.0-dev \
    libgstreamer-plugins-base1.0-dev \
    gstreamer1.0-plugins-base \
    gstreamer1.0-plugins-good \
    gstreamer1.0-plugins-bad \
    gstreamer1.0-plugins-ugly
```

### 3. Increase Swap Space (if needed)

```bash
# Check current swap
free -h

# If less than 2GB swap, create temporary swap file
sudo fallocate -l 2G /tmp/build_swap
sudo chmod 600 /tmp/build_swap
sudo mkswap /tmp/build_swap
sudo swapon /tmp/build_swap
```

### 4. Clone OpenAuto Properly

```bash
cd /opt/android-auto-hud

# Clone with all submodules
git clone --recursive https://github.com/f1xpl/openauto.git

# If that fails, try step by step
git clone https://github.com/f1xpl/openauto.git
cd openauto
git submodule update --init --recursive
```

### 5. Verify AASDK Submodule

```bash
cd openauto

# Check if AASDK exists and has the required files
ls -la aasdk/
ls -la aasdk/include/f1x/aasdk/IOPromise.hpp

# If missing, manually clone AASDK
rm -rf aasdk
git clone https://github.com/f1xpl/aasdk.git

# Verify the header file exists
ls -la aasdk/include/f1x/aasdk/IOPromise.hpp
```

### 6. Build AASDK First

```bash
cd aasdk
mkdir -p build
cd build

cmake -DCMAKE_BUILD_TYPE=Release ../
make -j$(nproc --ignore=1)

cd ../../  # Back to openauto directory
```

### 7. Build OpenAuto

```bash
mkdir -p build
cd build

# Configure with proper paths
cmake \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CXX_STANDARD=14 \
    -DRPI_BUILD=TRUE \
    -DAASDK_INCLUDE_DIRS="../aasdk/include" \
    -DAASDK_LIBRARIES="../aasdk/build" \
    -DGST_BUILD=TRUE \
    -DQT_BUILD=TRUE \
    ../

# Build (use fewer cores to avoid memory issues)
make -j$(nproc --ignore=1)

# Install
sudo make install
```

### 8. Clean Up Temporary Swap

```bash
# Remove temporary swap file if created
sudo swapoff /tmp/build_swap
sudo rm -f /tmp/build_swap
```

## Alternative Solutions

### Option 1: Use Different OpenAuto Branch

Sometimes the main branch has issues. Try the development branch:

```bash
cd /opt/android-auto-hud
rm -rf openauto

git clone --recursive -b development https://github.com/f1xpl/openauto.git
cd openauto
# Continue with build steps above
```

### Option 2: Use Pre-built OpenAuto (if available)

Check for pre-built packages:

```bash
# Some distributions may have OpenAuto packages
apt search openauto

# Or use AppImage if available
wget https://github.com/f1xpl/openauto/releases/download/latest/OpenAuto-arm64.AppImage
chmod +x OpenAuto-arm64.AppImage
```

### Option 3: Use Simple Interface Instead

If OpenAuto continues to fail, use the lightweight browser-based interface:

```bash
sudo ./scripts/quick-setup.sh
```

This provides basic Android Auto functionality without the compilation complexity.

## Memory-Related Issues

### Error: "virtual memory exhausted"

```bash
# Increase swap space
sudo dphys-swapfile swapoff
sudo sed -i 's/CONF_SWAPSIZE=100/CONF_SWAPSIZE=2048/' /etc/dphys-swapfile
sudo dphys-swapfile setup
sudo dphys-swapfile swapon

# Try building with fewer parallel jobs
make -j1  # Use only 1 core
```

### Error: "c++: internal compiler error"

```bash
# Reduce compilation parallelism
make -j1

# Or use a different compiler
sudo apt install clang
export CC=clang
export CXX=clang++
cmake ...
```

## Qt5-Related Issues

### Error: "Qt5Core not found"

```bash
# Install Qt5 development packages
sudo apt install -y qt5-qmake qtbase5-dev qtbase5-dev-tools

# Set Qt5 environment
export Qt5_DIR=/usr/lib/aarch64-linux-gnu/cmake/Qt5
export CMAKE_PREFIX_PATH=/usr/lib/aarch64-linux-gnu/cmake/Qt5
```

### Error: "qtquickcontrols2 not found"

```bash
# Install Qt Quick Controls
sudo apt install -y qtquickcontrols2-5-dev qml-module-qtquick-controls2
```

## GStreamer Issues

### Error: "GStreamer development files not found"

```bash
# Install GStreamer development packages
sudo apt install -y \
    libgstreamer1.0-dev \
    libgstreamer-plugins-base1.0-dev \
    libgstreamer-plugins-good1.0-dev \
    pkg-config
```

## Protobuf Issues

### Error: "protobuf compiler not found"

```bash
# Install protobuf compiler
sudo apt install -y protobuf-compiler libprotobuf-dev

# Verify installation
protoc --version
```

## USB/libusb Issues

### Error: "libusb not found"

```bash
# Try different libusb package names
sudo apt install -y libusb-1.0-0-dev

# If that fails, try alternatives
sudo apt install -y libusb-dev
# or
sudo apt install -y libusb-1.0.0-dev
```

## Build Performance Tips

### Speed Up Compilation

1. **Use Ninja instead of Make:**
   ```bash
   cmake -G Ninja ../
   ninja -j$(nproc --ignore=1)
   ```

2. **Use ccache:**
   ```bash
   sudo apt install ccache
   export CC="ccache gcc"
   export CXX="ccache g++"
   ```

3. **Optimize for Raspberry Pi:**
   ```bash
   export CFLAGS="-O2 -mcpu=cortex-a76"
   export CXXFLAGS="-O2 -mcpu=cortex-a76"
   ```

## Verification Steps

After successful build:

```bash
# Check if binary exists
ls -la /opt/android-auto-hud/openauto/build/bin/autoapp

# Check dependencies
ldd /opt/android-auto-hud/openauto/build/bin/autoapp

# Test startup (should show help)
/opt/android-auto-hud/openauto/build/bin/autoapp --help
```

## Common Error Messages and Solutions

### "cannot find -laasdk"
- **Solution**: Build AASDK first, then OpenAuto

### "No rule to make target 'aasdk/libaasdk.a'"
- **Solution**: AASDK build incomplete, rebuild AASDK

### "Package 'Qt5Quick' not found"
- **Solution**: `sudo apt install qtdeclarative5-dev`

### "fatal error: boost/asio.hpp: No such file"
- **Solution**: `sudo apt install libboost-all-dev`

### "error: #error "OpenSSL version too old""
- **Solution**: Update system or use newer OpenSSL

## Getting Help

If build issues persist:

1. **Check build logs:**
   ```bash
   # During build, redirect output to file
   make 2>&1 | tee build.log
   ```

2. **Check system resources:**
   ```bash
   free -h        # Memory usage
   df -h          # Disk space
   lscpu          # CPU info
   ```

3. **Try minimal build:**
   ```bash
   # Build with minimal features
   cmake -DRPI_BUILD=TRUE -DGST_BUILD=FALSE ../
   ```

## Working Configurations

### Raspberry Pi 5 + 4GB RAM
- ✅ Requires 2GB+ swap space
- ✅ Use `-j3` for compilation (not `-j4`)
- ✅ Build time: ~30-45 minutes

### Raspberry Pi 5 + 8GB RAM  
- ✅ Can use default swap
- ✅ Use `-j4` for compilation
- ✅ Build time: ~20-30 minutes

### Raspberry Pi 4 + 4GB RAM
- ⚠️ May need 2GB+ swap
- ✅ Use `-j2` for compilation
- ⚠️ Build time: ~45-60 minutes

---

**Last Updated**: December 2024
**Tested On**: Raspberry Pi 5, Raspberry Pi OS Bookworm (arm64) 