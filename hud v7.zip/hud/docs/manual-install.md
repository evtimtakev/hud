# Manual Installation Guide

This guide walks you through manually installing and configuring Android Auto HUD on Raspberry Pi 5.

## Prerequisites

- Raspberry Pi 5 with 4GB+ RAM
- MicroSD card (32GB+ recommended)
- Raspberry Pi OS (64-bit, Bullseye or newer)
- Internet connection
- Touch screen display

## Step 1: System Update

```bash
sudo apt update && sudo apt upgrade -y
```

## Step 2: Install Dependencies

### Core Development Tools
```bash
sudo apt install -y git cmake build-essential
```

### Qt5 Framework
For **Raspberry Pi OS Bookworm/Bullseye (newer versions):**
```bash
sudo apt install -y \
    qt5-qmake \
    qtbase5-dev \
    qtbase5-dev-tools \
    qtmultimedia5-dev \
    qtconnectivity5-dev \
    libqt5multimedia5-plugins \
    libqt5webchannel5-dev \
    libqt5widgets5 \
    libqt5core5a \
    libqt5quick5 \
    libqt5quickwidgets5 \
    libqt5qml5 \
    libqt5network5 \
    libqt5gui5 \
    libqt5dbus5 \
    libqt5xml5 \
    libqt5opengl5-dev \
    qml-module-qtquick2 \
    qml-module-qtquick-controls \
    qml-module-qtquick-controls2
```

For **older Raspberry Pi OS versions (if qt5-default is available):**
```bash
sudo apt install -y \
    qt5-default \
    qtmultimedia5-dev \
    qtconnectivity5-dev \
    libqt5multimedia5-plugins \
    libqt5webchannel5-dev \
    libqt5widgets5 \
    libqt5core5a \
    libqt5quick5 \
    libqt5quickwidgets5 \
    libqt5qml5 \
    libqt5network5 \
    libqt5gui5 \
    libqt5dbus5 \
    libqt5xml5
```

### Media and Audio Libraries
```bash
sudo apt install -y \
    libboost-all-dev \
    libusb-1.0.0-dev \
    libssl-dev \
    libprotobuf-dev \
    protobuf-compiler \
    librtaudio-dev \
    pulseaudio \
    pulseaudio-module-bluetooth \
    bluez \
    bluez-tools
```

### GStreamer
```bash
sudo apt install -y \
    gstreamer1.0-plugins-base \
    gstreamer1.0-plugins-good \
    gstreamer1.0-plugins-ugly \
    gstreamer1.0-plugins-bad \
    gstreamer1.0-libav \
    gstreamer1.0-tools \
    gstreamer1.0-alsa \
    gstreamer1.0-pulseaudio \
    libgstreamer1.0-dev \
    libgstreamer-plugins-base1.0-dev
```

### X Server and Window Manager
```bash
sudo apt install -y \
    xorg \
    xinit \
    x11-xserver-utils \
    xserver-xorg-legacy \
    openbox \
    lightdm \
    unclutter
```

### USB and Device Support
```bash
# Note: libusb package name varies by OS version
# Try libusb-1.0-0-dev first, fallback to libusb-dev
sudo apt install -y \
    libusb-1.0-0-dev \
    usbmuxd \
    libimobiledevice6 \
    libimobiledevice-utils

# If libusb-1.0-0-dev not found, try:
# sudo apt install -y libusb-dev
```

## Step 3: Configure Display Rotation

Edit `/boot/config.txt`:
```bash
sudo nano /boot/config.txt
```

Add these lines:
```
# Display rotation (180 degrees for dashboard mounting)
display_rotate=2

# Touch rotation to match display
input_rotate=2

# GPU memory allocation
gpu_mem=128

# Enable hardware acceleration
dtoverlay=vc4-kms-v3d

# Audio configuration
dtparam=audio=on

# DSI display configuration for 5-inch display
framebuffer_width=800
framebuffer_height=480
disable_overscan=1
display_auto_detect=1
enable_dsi_auto_timing=1
```

## Step 4: Create Project Directories

```bash
sudo mkdir -p /opt/android-auto-hud
sudo mkdir -p /var/log/android-auto-hud
sudo mkdir -p /home/pi/.config/autostart
```

## Step 5: Install OpenAuto

```bash
cd /opt/android-auto-hud
sudo git clone https://github.com/f1xpl/openauto.git
cd openauto
sudo git submodule update --init --recursive

mkdir build
cd build
sudo cmake ../
sudo make -j4
sudo make install
```

## Step 6: Configure Android Device Support

Create udev rules for Android devices:
```bash
sudo nano /etc/udev/rules.d/51-android.rules
```

Add these rules:
```
# Google
SUBSYSTEM=="usb", ATTR{idVendor}=="18d1", MODE="0666", GROUP="plugdev"
# Samsung
SUBSYSTEM=="usb", ATTR{idVendor}=="04e8", MODE="0666", GROUP="plugdev"
# LG
SUBSYSTEM=="usb", ATTR{idVendor}=="1004", MODE="0666", GROUP="plugdev"
# Huawei
SUBSYSTEM=="usb", ATTR{idVendor}=="12d1", MODE="0666", GROUP="plugdev"
# HTC
SUBSYSTEM=="usb", ATTR{idVendor}=="0bb4", MODE="0666", GROUP="plugdev"
# Sony
SUBSYSTEM=="usb", ATTR{idVendor}=="0fce", MODE="0666", GROUP="plugdev"
# Motorola
SUBSYSTEM=="usb", ATTR{idVendor}=="22b8", MODE="0666", GROUP="plugdev"
# OnePlus
SUBSYSTEM=="usb", ATTR{idVendor}=="2a70", MODE="0666", GROUP="plugdev"
# Xiaomi
SUBSYSTEM=="usb", ATTR{idVendor}=="2717", MODE="0666", GROUP="plugdev"
```

Reload udev rules:
```bash
sudo udevadm control --reload-rules
```

## Step 7: Create Startup Script

```bash
sudo nano /opt/android-auto-hud/start-hud.sh
```

Add the following content:
```bash
#!/bin/bash

# Wait for X server to be ready
while ! pgrep -x "Xorg" > /dev/null; do
    sleep 1
done

# Wait a bit more for everything to settle
sleep 5

# Set display
export DISPLAY=:0

# Hide cursor
unclutter -idle 1 &

# Start OpenAuto
cd /opt/android-auto-hud/openauto/build/bin
./autoapp
```

Make it executable:
```bash
sudo chmod +x /opt/android-auto-hud/start-hud.sh
```

## Step 8: Create Systemd Service

```bash
sudo nano /etc/systemd/system/android-auto-hud.service
```

Add this content:
```ini
[Unit]
Description=Android Auto HUD Service
After=graphical-session.target
Wants=graphical-session.target

[Service]
Type=simple
User=pi
Group=pi
WorkingDirectory=/opt/android-auto-hud
ExecStart=/opt/android-auto-hud/start-hud.sh
Restart=always
RestartSec=5
Environment=DISPLAY=:0
Environment=XDG_RUNTIME_DIR=/run/user/1000

[Install]
WantedBy=graphical-session.target
```

Enable the service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable android-auto-hud.service
```

## Step 9: Configure Auto-login

Set graphical target as default:
```bash
sudo systemctl set-default graphical.target
```

Configure LightDM for auto-login:
```bash
sudo nano /etc/lightdm/lightdm.conf
```

Modify these lines:
```
autologin-user=pi
autologin-user-timeout=0
```

## Step 10: Configure X Server Permissions

```bash
sudo nano /etc/X11/Xwrapper.config
```

Change:
```
allowed_users=anybody
```

## Step 11: Add User to Required Groups

```bash
sudo usermod -a -G audio,video,input,dialout,plugdev,netdev pi
```

## Step 12: Set Permissions

```bash
sudo chown -R pi:pi /opt/android-auto-hud
sudo chown -R pi:pi /home/pi/.config
```

## Step 13: Reboot

```bash
sudo reboot
```

## Verification

After reboot:

1. Check if the service is running:
   ```bash
   sudo systemctl status android-auto-hud
   ```

2. Check display rotation:
   - The display should be rotated 180°
   - Touch input should match the rotation

3. Connect Android device:
   - Enable Developer Options
   - Enable USB Debugging
   - Connect via USB cable

## Troubleshooting

### Display Issues
- Check `/boot/config.txt` for rotation settings
- Verify HDMI connection and settings
- Test with `xrandr` command

### Service Issues
- Check logs: `sudo journalctl -u android-auto-hud`
- Verify X server is running: `ps aux | grep Xorg`
- Check permissions on startup script

### Android Connection Issues
- Verify USB cable supports data transfer
- Check udev rules: `lsusb` and `/etc/udev/rules.d/51-android.rules`
- Ensure USB debugging is enabled on phone

### Audio Issues
- Run `sudo raspi-config` and select audio output
- Check PulseAudio: `pulseaudio --check`
- Test audio: `speaker-test -t wav`

## Configuration Files

### OpenAuto Configuration
Edit `/opt/android-auto-hud/autoapp.ini` to customize:
- Video resolution
- Audio settings
- Input preferences
- Performance options

### Display Settings
Edit `/boot/config.txt` to adjust:
- Display rotation
- Resolution
- GPU memory
- HDMI settings

## Advanced Configuration

### Performance Tuning
1. Increase GPU memory if needed
2. Adjust video resolution for performance
3. Enable/disable hardware acceleration
4. Configure audio sample rates

### Custom Interface
1. Modify OpenAuto theme
2. Add custom applications
3. Configure additional input devices
4. Set up wireless Android Auto (if supported)

## Maintenance

### Regular Updates
```bash
# Update system
sudo apt update && sudo apt upgrade

# Update OpenAuto (if needed)
cd /opt/android-auto-hud/openauto
sudo git pull
cd build
sudo make
sudo make install
```

### Log Rotation
Configure log rotation to prevent disk space issues:
```bash
sudo nano /etc/logrotate.d/android-auto-hud
```

### Backup Configuration
Back up important files:
- `/boot/config.txt`
- `/opt/android-auto-hud/`
- `/etc/systemd/system/android-auto-hud.service`
- `/etc/udev/rules.d/51-android.rules` 