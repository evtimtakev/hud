# Qt5 Installation Troubleshooting

This guide helps resolve common Qt5 installation issues on different Raspberry Pi OS versions.

## Common Error: "qt5-default has no installation candidate"

This error occurs on newer Raspberry Pi OS versions (Bookworm and later) where the `qt5-default` package has been removed.

### Solution

The installation script automatically detects your OS version and installs the correct packages. If you're installing manually, use the appropriate commands below.

## For Raspberry Pi OS Bookworm/Bullseye (2023+)

```bash
# Install Qt5 development packages
sudo apt update
sudo apt install -y \
    qt5-qmake \
    qtbase5-dev \
    qtbase5-dev-tools \
    qtmultimedia5-dev \
    qtconnectivity5-dev \
    libqt5multimedia5-plugins \
    libqt5webchannel5-dev \
    libqt5widgets5 \
    libqt5core5a \
    libqt5quick5 \
    libqt5quickwidgets5 \
    libqt5qml5 \
    libqt5network5 \
    libqt5gui5 \
    libqt5dbus5 \
    libqt5xml5 \
    libqt5opengl5-dev \
    qml-module-qtquick2 \
    qml-module-qtquick-controls \
    qml-module-qtquick-controls2
```

## For Older Raspberry Pi OS Versions (Buster and earlier)

```bash
# Install Qt5 using the legacy package
sudo apt update
sudo apt install -y qt5-default qtmultimedia5-dev qtconnectivity5-dev
```

## Verification

Check if Qt5 is properly installed:

```bash
# Check Qt5 version
qmake --version

# Check installed Qt5 packages
dpkg -l | grep qt5

# Verify Qt5 development files
ls /usr/include/qt5/
```

## Alternative Solutions

### Option 1: Use Simple Interface (No Qt5 Required)

If Qt5 installation continues to fail, the project includes a fallback that uses Chromium browser instead:

```bash
# This will work without Qt5
sudo ./install.sh
# The script will automatically use the simple interface if OpenAuto fails
```

### Option 2: Manual Qt5 Installation

If automatic detection fails:

```bash
# Force install specific Qt5 packages
sudo apt install -y \
    qtbase5-dev \
    qt5-qmake \
    qtbase5-dev-tools

# Then retry the main installation
sudo ./install.sh
```

### Option 3: Build Qt5 from Source (Advanced)

For custom Qt5 builds:

```bash
# Install build dependencies
sudo apt install -y build-essential cmake

# Download and build Qt5 (this takes several hours)
wget https://download.qt.io/archive/qt/5.15/5.15.2/single/qt-everywhere-src-5.15.2.tar.xz
tar xf qt-everywhere-src-5.15.2.tar.xz
cd qt-everywhere-src-5.15.2

./configure -opensource -confirm-license -nomake examples -nomake tests
make -j$(nproc)
sudo make install
```

## OpenAuto Build Issues

If OpenAuto fails to build due to Qt5 issues:

### Check Dependencies

```bash
# Verify all required packages
sudo apt install -y \
    libboost-all-dev \
    libprotobuf-dev \
    protobuf-compiler \
    libssl-dev \
    cmake \
    build-essential
```

### Alternative: Use Simple Interface

The installation script automatically falls back to a simple browser-based interface if OpenAuto compilation fails.

### Manual OpenAuto Build

```bash
cd /opt/android-auto-hud

# Clean previous attempts
rm -rf openauto

# Clone with specific branch
git clone --branch development https://github.com/f1xpl/openauto.git
cd openauto
git submodule update --init --recursive

# Build with specific flags
mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ../
make -j$(nproc)

# If build succeeds
sudo make install
```

## OS Version Detection Issues

If the script incorrectly detects your OS version:

```bash
# Check your actual OS version
lsb_release -a

# Force manual Qt5 installation
sudo apt install -y qtbase5-dev qt5-qmake qtbase5-dev-tools

# Then run installation with force flag
sudo FORCE_QT5=true ./install.sh
```

## Memory Issues During Compilation

If compilation fails due to memory issues:

```bash
# Increase swap space temporarily
sudo dphys-swapfile swapoff
sudo sed -i 's/CONF_SWAPSIZE=100/CONF_SWAPSIZE=1024/' /etc/dphys-swapfile
sudo dphys-swapfile setup
sudo dphys-swapfile swapon

# Try compilation again
sudo ./install.sh

# Restore original swap after installation
sudo sed -i 's/CONF_SWAPSIZE=1024/CONF_SWAPSIZE=100/' /etc/dphys-swapfile
sudo dphys-swapfile setup
```

## Skip OpenAuto Installation

To install just the display configuration without OpenAuto:

```bash
# Use quick setup instead
sudo ./scripts/quick-setup.sh

# This configures the display and installs a simple test interface
```

## Getting Help

1. **Check installation logs:**
   ```bash
   sudo journalctl -u android-auto-hud
   ```

2. **Verify system requirements:**
   ```bash
   sudo ./scripts/android-auto-service.sh check
   ```

3. **Test simple interface:**
   ```bash
   startx /opt/android-auto-hud/simple-auto/launcher.sh
   ```

## Working Configurations

### Raspberry Pi 5 + Bookworm
- ✅ qtbase5-dev + qt5-qmake
- ✅ Simple chromium interface
- ⚠️ OpenAuto may require additional dependencies

### Raspberry Pi 4 + Bullseye
- ✅ qtbase5-dev + qt5-qmake
- ✅ OpenAuto builds successfully
- ✅ Full functionality

### Raspberry Pi 4 + Buster
- ✅ qt5-default (legacy)
- ✅ OpenAuto builds successfully
- ✅ Full functionality 