# 5-Inch Display Types and Configuration

This document explains the different types of 5-inch displays that can be connected directly to the Raspberry Pi 5 and their specific configuration requirements.

## Supported Display Types

### 1. DSI Displays (Recommended for this project)
DSI (Display Serial Interface) displays connect directly to the Raspberry Pi's DSI connector using a flat ribbon cable.

**Common 5" DSI Models:**
- Waveshare 5" DSI Touch Display (800x480)
- Elecrow 5" DSI Capacitive Touch
- Adafruit 5" DSI Touch Display
- Generic 5" DSI touchscreen displays

**Physical Connection:**
1. Connect the DSI ribbon cable to the Raspberry Pi's DSI port (between HDMI and USB-C)
2. Connect power to display (usually via GPIO 5V/GND or separate connector)
3. Connect touch I2C pins if required (usually auto-detected)

**Optimized Configuration for 5" DSI:**
```bash
# In /boot/config.txt
dtoverlay=vc4-kms-v3d
framebuffer_width=800
framebuffer_height=480
disable_overscan=1
display_auto_detect=1
enable_dsi_auto_timing=1
display_rotate=2
input_rotate=2
```

### 2. GPIO Displays
These displays connect via the GPIO pins and use SPI communication.

**Common Models:**
- Waveshare 5" HDMI LCD (when used in GPIO mode)
- Adafruit 5" TFT displays
- Generic SPI TFT displays

**Configuration:**
```bash
# In /boot/config.txt
dtoverlay=vc4-kms-v3d
dtoverlay=spi1-3cs
framebuffer_width=800
framebuffer_height=480
disable_overscan=1
```

### 3. USB Displays
USB-connected displays that appear as external monitors.

**Configuration:**
```bash
# Usually auto-detected, but may need:
framebuffer_width=800
framebuffer_height=480
```

## Display-Specific Settings

### For Waveshare 5" DSI
```bash
# /boot/config.txt additions
dtoverlay=vc4-kms-v3d
display_auto_detect=1
framebuffer_width=800
framebuffer_height=480
```

### For Generic DSI Displays
```bash
# /boot/config.txt additions
dtoverlay=vc4-kms-v3d
framebuffer_width=800
framebuffer_height=480
disable_overscan=1
```

### For SPI/GPIO Displays
```bash
# /boot/config.txt additions
dtoverlay=vc4-kms-v3d
dtoverlay=spi1-3cs
enable_dpi_lcd=1
display_default_lcd=1
dpi_group=2
dpi_mode=87
dpi_output_format=0x7f216
framebuffer_width=800
framebuffer_height=480
```

## Touch Screen Configuration

### Capacitive Touch (Most 5" displays)
```bash
# Usually auto-detected, but if needed:
dtoverlay=rpi-ft5406
```

### Resistive Touch
```bash
# For resistive touchscreens:
dtoverlay=ads7846,cs=1,penirq=25,penirq_pull=2,speed=50000,keep_vref_on=1,swapxy=1,pmax=255,xohms=150,xmin=200,xmax=3900,ymin=200,ymax=3900
```

## Troubleshooting

### DSI Display Not Working
1. **Check Physical DSI Connection:**
   - Ensure DSI ribbon cable is properly seated in both connectors
   - Check that cable is not damaged or twisted
   - Verify display power connection (5V/GND from GPIO)
   - Ensure cable connectors are locked (blue tabs pushed down)

2. **Check DSI Configuration:**
   ```bash
   # View current DSI config
   cat /boot/config.txt | grep -E "(display|framebuffer|dtoverlay|dsi)"
   
   # Check for DSI detection
   dmesg | grep -i dsi
   ```

3. **Test DSI Display:**
   ```bash
   # Check if DSI display is detected
   vcgencmd get_lcd_info
   
   # View framebuffer info
   fbset
   
   # Test display output
   fbi -T 1 /opt/vc/src/hello_pi/hello_triangle/Lenna.jpg
   ```

4. **DSI-Specific Troubleshooting:**
   ```bash
   # Force DSI timing recalculation
   echo 'enable_dsi_auto_timing=1' | sudo tee -a /boot/config.txt
   
   # Enable DSI debug
   echo 'dtdebug=on' | sudo tee -a /boot/config.txt
   
   # Check DSI status
   cat /sys/kernel/debug/dri/0/dsi_panel_info
   ```

### Touch Not Working
1. **Check Touch Detection:**
   ```bash
   # List input devices
   cat /proc/bus/input/devices
   
   # Test touch input
   evtest
   ```

2. **Calibrate Touch:**
   ```bash
   # Install calibration tool
   sudo apt install xinput-calibrator
   
   # Run calibration
   xinput_calibrator
   ```

### Display Orientation Issues
```bash
# Rotate display 180 degrees
echo 'display_rotate=2' | sudo tee -a /boot/config.txt

# Rotate touch input to match
echo 'input_rotate=2' | sudo tee -a /boot/config.txt
```

## Performance Optimization

### For Better Performance on 5" Displays:
```bash
# Increase GPU memory
gpu_mem=128

# Enable hardware acceleration
dtoverlay=vc4-kms-v3d

# Optimize for small screens
framebuffer_depth=16  # Use 16-bit color depth for performance
```

### Reduce Resource Usage:
```bash
# Disable unnecessary features
dtparam=audio=off  # If using USB audio instead
disable_camera_led=1
disable_splash=1
```

## Common Display Models

### Recommended 5" Displays:

1. **Waveshare 5" DSI Touch**
   - Resolution: 800x480
   - Interface: DSI + I2C (touch)
   - Power: 5V via GPIO

2. **Elecrow 5" Capacitive Touch**
   - Resolution: 800x480
   - Interface: DSI
   - Multi-touch support

3. **Generic 5" DSI Displays**
   - Usually work with standard DSI configuration
   - Check manufacturer specifications

## Installation Notes

The main installation script automatically configures for direct display connection by:
- Removing HDMI-specific settings
- Setting appropriate framebuffer dimensions
- Disabling overscan
- Enabling hardware acceleration

For display-specific requirements, you may need to add additional overlays or settings to `/boot/config.txt` after installation. 