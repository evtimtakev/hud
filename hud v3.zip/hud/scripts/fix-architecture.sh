#!/bin/bash

# Architecture Fix Script for Android Auto HUD
# Diagnoses and fixes architecture-related package installation issues

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}    Android Auto HUD - Architecture Fix${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

print_header

# Get system information
ARCHITECTURE=$(dpkg --print-architecture)
SYSTEM_ARCH=$(uname -m)
OS_VERSION=$(lsb_release -cs 2>/dev/null || echo "unknown")
FOREIGN_ARCHS=$(dpkg --print-foreign-architectures 2>/dev/null || echo "none")

print_status "System Information:"
echo "  OS Version: $(lsb_release -ds 2>/dev/null || echo "Unknown")"
echo "  Codename: $OS_VERSION"
echo "  Primary Architecture: $ARCHITECTURE"
echo "  System Architecture: $SYSTEM_ARCH"
echo "  Foreign Architectures: $FOREIGN_ARCHS"
echo ""

# Check for Raspberry Pi
if grep -q "Raspberry Pi" /proc/cpuinfo; then
    print_success "Running on Raspberry Pi"
    RPI_MODEL=$(grep "Model" /proc/cpuinfo | cut -d: -f2 | sed 's/^ *//')
    echo "  Model: $RPI_MODEL"
else
    print_warning "Not running on Raspberry Pi"
fi
echo ""

# Check for architecture problems
print_status "Checking for architecture issues..."

ISSUES_FOUND=0

# Check for i386 architecture causing problems
if echo "$FOREIGN_ARCHS" | grep -q "i386"; then
    print_error "i386 architecture detected - this can cause conflicts on ARM systems"
    ISSUES_FOUND=1
fi

# Check for mismatched architectures
if [[ "$ARCHITECTURE" != "arm64" && "$ARCHITECTURE" != "armhf" ]] && grep -q "Raspberry Pi" /proc/cpuinfo; then
    print_error "Architecture mismatch: Raspberry Pi should use arm64 or armhf, found $ARCHITECTURE"
    ISSUES_FOUND=1
fi

# Check for problematic repositories
if grep -q "i386" /etc/apt/sources.list /etc/apt/sources.list.d/* 2>/dev/null; then
    print_warning "Found i386 references in repository sources"
    ISSUES_FOUND=1
fi

if [ $ISSUES_FOUND -eq 0 ]; then
    print_success "No architecture issues detected"
else
    echo ""
    print_status "Fixing architecture issues..."
    
    # Fix 1: Remove i386 architecture if present
    if echo "$FOREIGN_ARCHS" | grep -q "i386"; then
        print_status "Removing i386 architecture..."
        dpkg --remove-architecture i386 2>/dev/null || print_warning "Could not remove i386 architecture"
    fi
    
    # Fix 2: Clean package cache
    print_status "Cleaning package cache..."
    apt clean
    apt autoclean
    rm -rf /var/lib/apt/lists/*
    
    # Fix 3: Update package database
    print_status "Updating package database..."
    apt update
    
    # Fix 4: Set architecture preferences
    print_status "Setting architecture preferences..."
    cat > /etc/apt/preferences.d/99-raspberry-pi-architecture << EOF
Package: *
Pin: version *
Pin-Priority: 100

Package: *
Pin: release a=* l=* c=* origin=* architecture=$ARCHITECTURE
Pin-Priority: 500
EOF
    
    # Fix 5: Remove problematic repository configurations
    print_status "Checking repository configurations..."
    
    # Remove any Node.js repositories that might have wrong architecture
    if [ -f /etc/apt/sources.list.d/nodesource.list ]; then
        print_status "Removing potentially problematic NodeSource repository..."
        rm -f /etc/apt/sources.list.d/nodesource.list
    fi
    
    # Fix 6: Reconfigure dpkg
    print_status "Reconfiguring package manager..."
    dpkg --configure -a 2>/dev/null || true
    
    print_success "Architecture fixes applied"
fi

echo ""
print_status "Testing package installation..."

# Test installing a simple package
if apt install -y --dry-run wget >/dev/null 2>&1; then
    print_success "Package installation test passed"
else
    print_error "Package installation test failed"
    print_status "Try running: sudo apt update && sudo apt upgrade"
fi

echo ""
print_status "Architecture Status After Fixes:"
echo "  Primary Architecture: $(dpkg --print-architecture)"
echo "  Foreign Architectures: $(dpkg --print-foreign-architectures 2>/dev/null || echo "none")"

# Check if we can install common packages
echo ""
print_status "Checking package availability for your architecture..."

TEST_PACKAGES=("git" "cmake" "build-essential" "qt5-qmake" "qtbase5-dev")

for pkg in "${TEST_PACKAGES[@]}"; do
    if apt-cache policy "$pkg" | grep -q "Candidate:"; then
        echo -e "  ${GREEN}✓${NC} $pkg"
    else
        echo -e "  ${RED}✗${NC} $pkg"
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_status "Architecture fix complete!"
echo ""
echo "If you were getting architecture errors, try running the installation again:"
echo "  sudo ./install.sh"
echo ""
echo "If problems persist, check the package availability above and install"
echo "packages manually using the alternatives shown."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" 