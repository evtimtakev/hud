# Android Auto HUD Setup Guide

## 🚗 Project Overview

This project creates a complete Android Auto Head-Up Display (HUD) system for Raspberry Pi 5 with:
- ✅ **5-inch Display Optimized** - 800x480 resolution with perfect scaling
- ✅ **180° Display Rotation** - Perfect for dashboard mounting
- ✅ **Auto-startup on boot** - No manual intervention needed
- ✅ **Touch screen support** - Full interaction capability
- ✅ **Android device integration** - Plug-and-play USB connection
- ✅ **Audio support** - 3.5mm jack and USB audio output

## 📁 Project Structure

```
hud/
├── install.sh                    # Main installation script
├── README.md                     # Project documentation
├── SETUP.md                      # This setup guide
├── config/
│   └── autoapp.ini              # OpenAuto configuration
├── scripts/
│   ├── android-auto-service.sh  # Service management
│   ├── display-config.sh        # Display configuration
│   └── quick-setup.sh           # Quick setup script
└── docs/
    └── manual-install.md        # Detailed manual installation
```

## 🔧 Installation Options

### Option 1: Quick Installation (Recommended)

Copy this project to your Raspberry Pi and run:

```bash
# Clone or copy the project to your Raspberry Pi
git clone <your-repo-url> android-auto-hud
cd android-auto-hud

# Make scripts executable
chmod +x *.sh scripts/*.sh

# Run the main installation
sudo ./install.sh
```

### Option 2: Quick Setup (Test First)

If you want to test basic functionality quickly:

```bash
sudo ./scripts/quick-setup.sh
sudo reboot
```

### Option 3: Manual Installation

Follow the detailed guide in `docs/manual-install.md` for step-by-step installation.

## 🖥️ For Windows Users

If you're developing on Windows (like this project was created), follow these steps:

1. **Transfer to Raspberry Pi:**
   - Use SCP, SFTP, or USB drive to copy files to your Raspberry Pi
   - Or set up a Git repository and clone on the Pi

2. **Make Scripts Executable on Pi:**
   ```bash
   find . -name "*.sh" -exec chmod +x {} \;
   ```

3. **Run Installation:**
   ```bash
   sudo ./install.sh
   ```

## 📋 Hardware Requirements

### Required Hardware
- **Raspberry Pi 5** (4GB+ RAM recommended)
- **MicroSD Card** (32GB+ Class 10)
- **Touch Screen Display** (5" optimized, 800x480, DSI connection)
- **USB-C Cable** (for Android phone connection)
- **Power Supply** (Official Raspberry Pi 5 PSU)

### Optional Hardware
- **External Speakers** (or use HDMI audio)
- **Case with Display Mount**
- **Car Power Adapter** (12V to USB-C)

## 📱 Phone Setup

### Android Phone Requirements
1. **Enable Developer Options:**
   - Go to Settings → About Phone
   - Tap "Build Number" 7 times
   - Developer Options will appear in Settings

2. **Enable USB Debugging:**
   - Go to Settings → Developer Options
   - Enable "USB Debugging"
   - Enable "Stay Awake" (optional)

3. **Install Android Auto App:**
   - Download from Google Play Store
   - Complete initial setup

## 🚀 Getting Started

### Step 1: Prepare Raspberry Pi
1. Flash Raspberry Pi OS (64-bit) to SD card
2. Enable SSH and WiFi if needed
3. Boot and connect to internet

### Step 2: Install the Project
```bash
# On Raspberry Pi
git clone <your-repo> hud
cd hud
sudo ./install.sh
```

### Step 3: Reboot and Test
```bash
sudo reboot
```

After reboot:
- Display should be rotated 180°
- System should auto-login
- Connect your Android phone via USB
- Android Auto interface should appear

## 🔧 Service Management

Use the service management script for control:

```bash
# Check status
sudo ./scripts/android-auto-service.sh status

# Start/stop service
sudo ./scripts/android-auto-service.sh start
sudo ./scripts/android-auto-service.sh stop

# View logs
sudo ./scripts/android-auto-service.sh logs

# Check system requirements
sudo ./scripts/android-auto-service.sh check
```

## 🎛️ Configuration

### Display Settings (DSI)
Edit `/boot/config.txt` to adjust:
- Rotation: `display_rotate=2` (180°)
- Resolution: `framebuffer_width=800` and `framebuffer_height=480`
- GPU Memory: `gpu_mem=128`
- Overscan: `disable_overscan=1` (for DSI displays)
- Auto-detect: `display_auto_detect=1` (for DSI)
- Timing: `enable_dsi_auto_timing=1` (for DSI)

### Audio Settings
```bash
# Select audio output (3.5mm jack or USB audio)
sudo raspi-config
# Choose Advanced Options → Audio → 3.5mm jack

# Test audio
speaker-test -t wav
```

### OpenAuto Settings
Edit `/opt/android-auto-hud/autoapp.ini` for:
- Video resolution and quality
- Audio settings
- Input preferences
- Performance options

## 🔍 Troubleshooting

### Display Issues
```bash
# Check display rotation
grep display_rotate /boot/config.txt

# Test display
sudo ./scripts/display-config.sh rotate 180
```

### Service Issues
```bash
# Check service status
sudo systemctl status android-auto-hud

# View detailed logs
sudo journalctl -u android-auto-hud -f

# Restart service
sudo systemctl restart android-auto-hud
```

### Android Connection Issues
```bash
# Check connected devices
lsusb

# Check udev rules
ls -la /etc/udev/rules.d/51-android.rules

# Test ADB connection (if available)
adb devices
```

### Performance Issues
```bash
# Check CPU usage
htop

# Check GPU memory
vcgencmd get_mem gpu

# Monitor temperature
vcgencmd measure_temp
```

## 📈 Performance Optimization

### For Better Performance:
1. **Increase GPU Memory:**
   ```bash
   # In /boot/config.txt
   gpu_mem=256
   ```

2. **Disable Unnecessary Services:**
   ```bash
   sudo systemctl disable bluetooth
   sudo systemctl disable wifi-powersave
   ```

3. **Optimize Video Settings:**
   - Lower resolution if needed
   - Adjust FPS in autoapp.ini
   - Enable hardware acceleration

## 🛡️ Security Notes

- Change default Pi password
- Disable SSH if not needed
- Keep system updated
- Use firewall if connecting to network

## 📖 Additional Resources

- **OpenAuto Documentation:** https://github.com/f1xpl/openauto
- **Raspberry Pi Documentation:** https://www.raspberrypi.org/documentation/
- **Android Auto Developer Guide:** https://developer.android.com/auto

## 🤝 Contributing

Feel free to:
- Report issues
- Suggest improvements
- Submit pull requests
- Share your setup photos!

## 📄 License

This project is released under the MIT License. See individual components for their specific licenses.

---

**Happy Driving! 🚗✨**

*Remember to follow traffic laws and use hands-free operation while driving.* 