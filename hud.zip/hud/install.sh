#!/bin/bash

# Android Auto HUD Installation Script for Raspberry Pi 5
# Author: Auto-generated installation script
# Description: Installs and configures Android Auto with 180° display rotation

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

# Check if running on Raspberry Pi
if ! grep -q "Raspberry Pi" /proc/cpuinfo; then
    print_warning "This script is designed for Raspberry Pi. Continuing anyway..."
fi

print_status "Starting Android Auto HUD installation..."

# Update system
print_status "Updating system packages..."
apt update && apt upgrade -y

# Install required dependencies
print_status "Installing dependencies..."
apt install -y \
    git \
    cmake \
    build-essential \
    qt5-default \
    qtmultimedia5-dev \
    qtconnectivity5-dev \
    qtwebengine5-dev \
    libqt5multimedia5-plugins \
    libqt5webchannel5-dev \
    libqt5widgets5 \
    libqt5core5a \
    libqt5quick5 \
    libqt5quickwidgets5 \
    libqt5qml5 \
    libqt5network5 \
    libqt5gui5 \
    libqt5dbus5 \
    libqt5xml5 \
    libboost-all-dev \
    libusb-1.0.0-dev \
    libssl-dev \
    libprotobuf-dev \
    protobuf-compiler \
    librtaudio-dev \
    pulseaudio \
    pulseaudio-module-bluetooth \
    bluez \
    bluez-tools \
    gstreamer1.0-plugins-base \
    gstreamer1.0-plugins-good \
    gstreamer1.0-plugins-ugly \
    gstreamer1.0-plugins-bad \
    gstreamer1.0-libav \
    gstreamer1.0-tools \
    gstreamer1.0-alsa \
    gstreamer1.0-pulseaudio \
    libgstreamer1.0-dev \
    libgstreamer-plugins-base1.0-dev \
    wget \
    unzip \
    xorg \
    xinit \
    x11-xserver-utils \
    xserver-xorg-legacy \
    openbox \
    lightdm \
    chromium-browser \
    usbmuxd \
    libimobiledevice6 \
    libimobiledevice-utils \
    python3-pip \
    python3-setuptools

# Install Node.js for web-based Android Auto
print_status "Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_18.x | bash -
apt install -y nodejs

# Create project directories
print_status "Creating project directories..."
mkdir -p /opt/android-auto-hud
mkdir -p /var/log/android-auto-hud
mkdir -p /home/pi/.config/autostart

# Copy project files
print_status "Copying project files..."
cp -r ./scripts/* /opt/android-auto-hud/ 2>/dev/null || true
cp -r ./config/* /opt/android-auto-hud/ 2>/dev/null || true

# Configure display rotation (180 degrees)
print_status "Configuring 180° display rotation..."
if ! grep -q "display_rotate=2" /boot/config.txt; then
    echo "display_rotate=2" >> /boot/config.txt
    print_success "Display rotation configured"
else
    print_status "Display rotation already configured"
fi

# Configure GPU memory split
if ! grep -q "gpu_mem=128" /boot/config.txt; then
    echo "gpu_mem=128" >> /boot/config.txt
    print_success "GPU memory configured"
fi

# Enable OpenGL
if ! grep -q "dtoverlay=vc4-kms-v3d" /boot/config.txt; then
    echo "dtoverlay=vc4-kms-v3d" >> /boot/config.txt
    print_success "OpenGL enabled"
fi

# Configure audio
print_status "Configuring audio..."
if ! grep -q "dtparam=audio=on" /boot/config.txt; then
    echo "dtparam=audio=on" >> /boot/config.txt
fi

# Install OpenAuto Pro (open-source Android Auto implementation)
print_status "Installing OpenAuto..."
cd /opt/android-auto-hud
if [ ! -d "openauto" ]; then
    git clone https://github.com/f1xpl/openauto.git
    cd openauto
    git submodule update --init --recursive
    
    mkdir build
    cd build
    cmake ../
    make -j4
    make install
    print_success "OpenAuto installed"
else
    print_status "OpenAuto already installed"
fi

# Create systemd service
print_status "Creating systemd service..."
cat > /etc/systemd/system/android-auto-hud.service << EOF
[Unit]
Description=Android Auto HUD Service
After=graphical-session.target
Wants=graphical-session.target

[Service]
Type=simple
User=pi
Group=pi
WorkingDirectory=/opt/android-auto-hud
ExecStart=/opt/android-auto-hud/start-hud.sh
Restart=always
RestartSec=5
Environment=DISPLAY=:0
Environment=XDG_RUNTIME_DIR=/run/user/1000

[Install]
WantedBy=graphical-session.target
EOF

# Enable the service
systemctl daemon-reload
systemctl enable android-auto-hud.service

# Configure auto-login for pi user
print_status "Configuring auto-login..."
systemctl set-default graphical.target
if [ ! -f /etc/lightdm/lightdm.conf.backup ]; then
    cp /etc/lightdm/lightdm.conf /etc/lightdm/lightdm.conf.backup
fi

sed -i 's/#autologin-user=/autologin-user=pi/' /etc/lightdm/lightdm.conf
sed -i 's/#autologin-user-timeout=0/autologin-user-timeout=0/' /etc/lightdm/lightdm.conf

# Configure X server to allow anyone to start it
sed -i 's/allowed_users=console/allowed_users=anybody/' /etc/X11/Xwrapper.config

# Add pi user to required groups
usermod -a -G audio,video,input,dialout,plugdev,netdev pi

# Set up udev rules for Android devices
print_status "Setting up USB/Android device rules..."
cat > /etc/udev/rules.d/51-android.rules << EOF
# Google
SUBSYSTEM=="usb", ATTR{idVendor}=="18d1", MODE="0666", GROUP="plugdev"
# Samsung
SUBSYSTEM=="usb", ATTR{idVendor}=="04e8", MODE="0666", GROUP="plugdev"
# LG
SUBSYSTEM=="usb", ATTR{idVendor}=="1004", MODE="0666", GROUP="plugdev"
# Huawei
SUBSYSTEM=="usb", ATTR{idVendor}=="12d1", MODE="0666", GROUP="plugdev"
# HTC
SUBSYSTEM=="usb", ATTR{idVendor}=="0bb4", MODE="0666", GROUP="plugdev"
# Sony
SUBSYSTEM=="usb", ATTR{idVendor}=="0fce", MODE="0666", GROUP="plugdev"
# Motorola
SUBSYSTEM=="usb", ATTR{idVendor}=="22b8", MODE="0666", GROUP="plugdev"
# OnePlus
SUBSYSTEM=="usb", ATTR{idVendor}=="2a70", MODE="0666", GROUP="plugdev"
# Xiaomi
SUBSYSTEM=="usb", ATTR{idVendor}=="2717", MODE="0666", GROUP="plugdev"
EOF

udevadm control --reload-rules

# Create startup script
print_status "Creating startup script..."
cat > /opt/android-auto-hud/start-hud.sh << 'EOF'
#!/bin/bash

# Wait for X server to be ready
while ! pgrep -x "Xorg" > /dev/null; do
    sleep 1
done

# Wait a bit more for everything to settle
sleep 5

# Set display
export DISPLAY=:0

# Hide cursor
unclutter -idle 1 &

# Start OpenAuto
cd /opt/android-auto-hud/openauto/build/bin
./autoapp

EOF

chmod +x /opt/android-auto-hud/start-hud.sh

# Install unclutter to hide cursor
apt install -y unclutter

# Create boot splash configuration
print_status "Configuring boot splash..."
if ! grep -q "disable_splash=1" /boot/config.txt; then
    echo "disable_splash=1" >> /boot/config.txt
fi

# Configure cmdline.txt for faster boot and no console messages
cp /boot/cmdline.txt /boot/cmdline.txt.backup
sed -i 's/console=tty1/console=tty3 quiet splash loglevel=3 logo.nologo vt.global_cursor_default=0/' /boot/cmdline.txt

# Configure DSI 5-inch display connection
print_status "Configuring DSI 5-inch display connection..."

# Remove any existing HDMI settings that might conflict
sed -i '/hdmi_force_hotplug/d' /boot/config.txt
sed -i '/hdmi_group/d' /boot/config.txt
sed -i '/hdmi_mode/d' /boot/config.txt
sed -i '/hdmi_cvt/d' /boot/config.txt

# Configure framebuffer for DSI display
if ! grep -q "framebuffer_width=800" /boot/config.txt; then
    echo "framebuffer_width=800" >> /boot/config.txt
fi

if ! grep -q "framebuffer_height=480" /boot/config.txt; then
    echo "framebuffer_height=480" >> /boot/config.txt
fi

# Disable overscan for DSI displays
if ! grep -q "disable_overscan=1" /boot/config.txt; then
    echo "disable_overscan=1" >> /boot/config.txt
fi

# Enable DSI display auto-detection
if ! grep -q "display_auto_detect=1" /boot/config.txt; then
    echo "display_auto_detect=1" >> /boot/config.txt
fi

# Ensure DSI is enabled
if ! grep -q "enable_dsi_auto_timing=1" /boot/config.txt; then
    echo "enable_dsi_auto_timing=1" >> /boot/config.txt
fi

print_success "DSI 5-inch display configured"

# Create configuration file
print_status "Creating configuration file..."
cat > /opt/android-auto-hud/config.ini << EOF
[Display]
rotation=180
resolution=800x480
fullscreen=true

[Audio]
output=analog
volume=80

[Android]
enable_wireless=false
enable_usb=true

[System]
auto_start=true
hide_cursor=true
EOF

# Set ownership
chown -R pi:pi /opt/android-auto-hud
chown -R pi:pi /home/pi/.config

print_success "Installation completed successfully!"
print_status "Configuration summary:"
echo "  ✓ Display rotation: 180°"
echo "  ✓ Resolution: 800x480 (DSI 5-inch optimized)"
echo "  ✓ Auto-start on boot: Enabled"
echo "  ✓ Audio output: 3.5mm jack (configurable)"
echo "  ✓ OpenAuto installed"
echo "  ✓ USB Android device support enabled"
echo ""
print_warning "Please reboot your Raspberry Pi to apply all changes:"
print_status "sudo reboot"
echo ""
print_status "After reboot:"
echo "1. Connect your Android phone via USB"
echo "2. Enable Developer Options and USB Debugging on your phone"
echo "3. The Android Auto interface should start automatically"
echo ""
print_status "Logs can be viewed with: sudo journalctl -u android-auto-hud" 