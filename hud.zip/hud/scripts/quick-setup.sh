#!/bin/bash

# Quick Setup Script for Android Auto HUD
# Performs essential configuration for immediate use

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_header() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}         Android Auto HUD - Quick Setup${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

print_status() {
    echo -e "${BLUE}[SETUP]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
    print_error "This script must be run with sudo"
    echo "Usage: sudo ./quick-setup.sh"
    exit 1
fi

print_header

# Quick system check
print_status "Performing quick system check..."

if ! grep -q "Raspberry Pi" /proc/cpuinfo; then
    print_warning "Not running on Raspberry Pi - some features may not work"
fi

# Check internet connection
if ping -c 1 google.com &> /dev/null; then
    print_success "Internet connection available"
else
    print_error "No internet connection - installation may fail"
    read -p "Continue anyway? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# Update package lists only (faster than full upgrade)
print_status "Updating package lists..."
apt update

# Install minimal required packages
print_status "Installing essential packages..."
apt install -y \
    git \
    cmake \
    build-essential \
    qt5-default \
    libusb-1.0.0-dev \
    pulseaudio \
    xorg \
    xinit \
    unclutter \
    wget

# Configure display rotation immediately
print_status "Configuring 180° display rotation..."
if ! grep -q "display_rotate=2" /boot/config.txt; then
    echo "display_rotate=2" >> /boot/config.txt
    print_success "Display rotation configured"
else
    print_success "Display rotation already configured"
fi

# Configure GPU memory
if ! grep -q "gpu_mem=" /boot/config.txt; then
    echo "gpu_mem=128" >> /boot/config.txt
    print_success "GPU memory configured"
fi

# Enable hardware acceleration
if ! grep -q "dtoverlay=vc4-kms-v3d" /boot/config.txt; then
    echo "dtoverlay=vc4-kms-v3d" >> /boot/config.txt
    print_success "Hardware acceleration enabled"
fi

# Configure touch rotation
if ! grep -q "input_rotate=2" /boot/config.txt; then
    echo "input_rotate=2" >> /boot/config.txt
    print_success "Touch rotation configured"
fi

# Create directories
print_status "Creating project directories..."
mkdir -p /opt/android-auto-hud
mkdir -p /var/log/android-auto-hud

# Download and build a lightweight Android Auto solution
print_status "Setting up Android Auto application..."
cd /opt/android-auto-hud

# Create a simple launcher script for testing
cat > /opt/android-auto-hud/test-launcher.sh << 'EOF'
#!/bin/bash

export DISPLAY=:0

# Simple test to verify display rotation and touch
echo "Testing Android Auto HUD setup..."
echo "Display should be rotated 180 degrees"

# Hide cursor
unclutter -idle 1 &

# Launch a simple test interface
if command -v chromium-browser &> /dev/null; then
    chromium-browser --kiosk --disable-infobars --disable-session-crashed-bubble \
        --disable-dev-shm-usage --no-sandbox \
        --rotate-to-landscape \
        --autoplay-policy=no-user-gesture-required \
        --window-size=800,480 \
        --force-device-scale-factor=1.0 \
        "data:text/html,<html><body style='margin:0;padding:20px;background:#000;color:#fff;font-family:Arial;text-align:center;font-size:18px;'><h1 style='font-size:28px;'>Android Auto HUD Test</h1><p>5-inch Display (800x480)</p><p>Display Rotation: 180°</p><p style='font-size:20px; padding:20px; border:2px solid white; margin:20px;'>Touch this text to test touch input</p><script>document.addEventListener('click',function(){alert('Touch working on 5-inch display!')});</script></body></html>" &
else
    # Fallback: create a simple Python test
         python3 -c "
import tkinter as tk
root = tk.Tk()
root.title('Android Auto HUD Test - 5 inch')
root.geometry('800x480')
root.attributes('-fullscreen', True)
root.configure(bg='black')
label = tk.Label(root, text='Android Auto HUD\n5-inch Display (800x480)\nSetup Complete!\nPress ESC to exit', 
                fg='white', bg='black', font=('Arial', 18))
label.pack(expand=True)
root.bind('<Escape>', lambda e: root.quit())
root.mainloop()
" &
fi

# Wait for X server
sleep 5

EOF

chmod +x /opt/android-auto-hud/test-launcher.sh

# Set up a simple service for testing
print_status "Creating test service..."
cat > /etc/systemd/system/android-auto-hud.service << EOF
[Unit]
Description=Android Auto HUD Test Service
After=graphical-session.target
Wants=graphical-session.target

[Service]
Type=simple
User=pi
Group=pi
WorkingDirectory=/opt/android-auto-hud
ExecStart=/opt/android-auto-hud/test-launcher.sh
Restart=on-failure
RestartSec=5
Environment=DISPLAY=:0
Environment=XDG_RUNTIME_DIR=/run/user/1000

[Install]
WantedBy=graphical-session.target
EOF

# Enable auto-login
print_status "Configuring auto-login..."
systemctl set-default graphical.target

# Configure lightdm for auto-login
if [ -f /etc/lightdm/lightdm.conf ]; then
    if [ ! -f /etc/lightdm/lightdm.conf.backup ]; then
        cp /etc/lightdm/lightdm.conf /etc/lightdm/lightdm.conf.backup
    fi
    sed -i 's/#autologin-user=/autologin-user=pi/' /etc/lightdm/lightdm.conf
    sed -i 's/#autologin-user-timeout=0/autologin-user-timeout=0/' /etc/lightdm/lightdm.conf
fi

# Configure X server permissions
if [ -f /etc/X11/Xwrapper.config ]; then
    sed -i 's/allowed_users=console/allowed_users=anybody/' /etc/X11/Xwrapper.config
fi

# Add pi user to required groups
usermod -a -G audio,video,input,dialout,plugdev,netdev pi

# Set up Android device permissions
print_status "Setting up Android device permissions..."
cat > /etc/udev/rules.d/51-android.rules << EOF
# Common Android device vendors
SUBSYSTEM=="usb", ATTR{idVendor}=="18d1", MODE="0666", GROUP="plugdev"
SUBSYSTEM=="usb", ATTR{idVendor}=="04e8", MODE="0666", GROUP="plugdev"
SUBSYSTEM=="usb", ATTR{idVendor}=="1004", MODE="0666", GROUP="plugdev"
SUBSYSTEM=="usb", ATTR{idVendor}=="12d1", MODE="0666", GROUP="plugdev"
SUBSYSTEM=="usb", ATTR{idVendor}=="0bb4", MODE="0666", GROUP="plugdev"
SUBSYSTEM=="usb", ATTR{idVendor}=="22b8", MODE="0666", GROUP="plugdev"
EOF

udevadm control --reload-rules

# Enable the service
systemctl daemon-reload
systemctl enable android-auto-hud.service

# Set ownership
chown -R pi:pi /opt/android-auto-hud

print_success "Quick setup completed!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${GREEN}Setup Summary:${NC}"
echo "✓ Display rotation: 180°"
echo "✓ Touch rotation: 180°"
echo "✓ Resolution: 800x480 (5-inch optimized)"
echo "✓ Auto-login: Enabled"
echo "✓ Test service: Created"
echo "✓ Android USB: Configured"
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "1. Reboot your Raspberry Pi: sudo reboot"
echo "2. After reboot, a test screen should appear"
echo "3. Run the full installation: sudo ./install.sh"
echo ""
echo -e "${BLUE}To test now without reboot:${NC}"
echo "startx /opt/android-auto-hud/test-launcher.sh"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" 