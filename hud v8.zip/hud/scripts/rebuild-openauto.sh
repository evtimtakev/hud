#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

print_status() { echo -e "${BLUE}[INFO]${NC} $1"; }
print_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
print_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
print_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    print_error "This script must be run as root (use sudo)"
    exit 1
fi

print_status "OpenAuto Rebuild Script"
print_status "This script will rebuild OpenAuto from scratch"
echo ""

# Navigate to project directory
cd /opt/android-auto-hud || {
    print_error "Android Auto HUD directory not found"
    exit 1
}

# Clean up existing build
print_status "Cleaning up existing OpenAuto build..."
if [ -d "openauto" ]; then
    rm -rf openauto/build
    print_status "Removed existing build directory"
fi

# Check if OpenAuto source exists
if [ ! -d "openauto" ]; then
    print_status "OpenAuto source not found, cloning repository..."
    git clone https://github.com/f1xpl/openauto.git --recursive
    if [ $? -ne 0 ]; then
        print_error "Failed to clone OpenAuto repository"
        exit 1
    fi
fi

# Navigate to OpenAuto directory
cd openauto

# Update submodules
print_status "Updating submodules..."
git submodule update --init --recursive

# Check for AASDK
if [ ! -d "aasdk" ] || [ -z "$(ls -A aasdk 2>/dev/null)" ]; then
    print_warning "AASDK submodule missing or empty, cloning manually..."
    rm -rf aasdk
    git clone https://github.com/f1xpl/aasdk.git aasdk
fi

# Build AASDK first
print_status "Building AASDK..."
cd aasdk

# Create and enter build directory
mkdir -p build
cd build

# Configure AASDK build
cmake -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_CXX_STANDARD=14 \
      -DCMAKE_CXX_FLAGS="-std=c++14 -Wno-error=deprecated-declarations -fpermissive" \
      ..

if [ $? -ne 0 ]; then
    print_error "AASDK CMake configuration failed"
    exit 1
fi

# Build AASDK
print_status "Compiling AASDK (this may take a while)..."
make -j$(nproc) || make -j1

if [ $? -ne 0 ]; then
    print_error "AASDK build failed"
    exit 1
fi

# Install AASDK
make install
ldconfig

print_success "AASDK built successfully"

# Return to OpenAuto directory
cd /opt/android-auto-hud/openauto

# Build OpenAuto
print_status "Building OpenAuto..."
mkdir -p build
cd build

# Configure OpenAuto build
cmake -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_CXX_STANDARD=14 \
      -DCMAKE_CXX_FLAGS="-std=c++14 -Wno-error=deprecated-declarations -fpermissive" \
      -DGST_PLUGIN_PATH="/usr/lib/arm-linux-gnueabihf/gstreamer-1.0" \
      ..

if [ $? -ne 0 ]; then
    print_error "OpenAuto CMake configuration failed"
    print_status "Trying with alternative settings..."
    
    # Try with simpler configuration
    cmake -DCMAKE_BUILD_TYPE=Release \
          -DCMAKE_CXX_STANDARD=11 \
          ..
    
    if [ $? -ne 0 ]; then
        print_error "OpenAuto configuration failed completely"
        exit 1
    fi
fi

# Build OpenAuto
print_status "Compiling OpenAuto (this may take a while)..."
make -j$(nproc) || make -j1

if [ $? -ne 0 ]; then
    print_error "OpenAuto build failed"
    print_status "Trying alternative build approach..."
    
    # Try building with single thread and verbose output
    make VERBOSE=1
    
    if [ $? -ne 0 ]; then
        print_error "OpenAuto build failed completely"
        print_status "Please check the build logs above for specific errors"
        exit 1
    fi
fi

# Check if binary was created
if [ -f "bin/autoapp" ]; then
    print_success "OpenAuto built successfully!"
    print_status "Binary location: $(pwd)/bin/autoapp"
    
    # Make sure it's executable
    chmod +x bin/autoapp
    
    # Set proper ownership
    chown -R test:test /opt/android-auto-hud
    
    print_success "OpenAuto rebuild completed!"
    print_status "You can now restart the Android Auto HUD service:"
    print_status "sudo systemctl restart android-auto-hud"
    
elif [ -f "autoapp" ]; then
    print_success "OpenAuto built successfully!"
    print_status "Binary location: $(pwd)/autoapp"
    
    # Create bin directory and move binary
    mkdir -p bin
    mv autoapp bin/
    chmod +x bin/autoapp
    
    # Set proper ownership
    chown -R test:test /opt/android-auto-hud
    
    print_success "OpenAuto rebuild completed!"
    print_status "You can now restart the Android Auto HUD service:"
    print_status "sudo systemctl restart android-auto-hud"
    
else
    print_error "OpenAuto binary not found after build"
    print_status "Build may have completed but binary is in unexpected location"
    print_status "Searching for autoapp binary..."
    
    FOUND_BINARY=$(find /opt/android-auto-hud/openauto -name "autoapp" -type f 2>/dev/null)
    if [ -n "$FOUND_BINARY" ]; then
        print_status "Found binary at: $FOUND_BINARY"
        
        # Create bin directory if it doesn't exist
        mkdir -p /opt/android-auto-hud/openauto/build/bin
        
        # Copy binary to expected location
        cp "$FOUND_BINARY" /opt/android-auto-hud/openauto/build/bin/autoapp
        chmod +x /opt/android-auto-hud/openauto/build/bin/autoapp
        chown -R test:test /opt/android-auto-hud
        
        print_success "Binary moved to standard location"
        print_status "You can now restart the Android Auto HUD service:"
        print_status "sudo systemctl restart android-auto-hud"
    else
        print_error "No autoapp binary found anywhere"
        exit 1
    fi
fi

print_status ""
print_status "Rebuild completed! Next steps:"
print_status "1. Restart the service: sudo systemctl restart android-auto-hud"
print_status "2. Check status: sudo systemctl status android-auto-hud"
print_status "3. View logs: sudo journalctl -u android-auto-hud -f" 