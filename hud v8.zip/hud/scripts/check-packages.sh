#!/bin/bash

# Package Availability Checker for Android Auto HUD
# Helps identify correct package names on different Raspberry Pi OS versions

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}    Android Auto HUD - Package Checker${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

check_package() {
    local package=$1
    local alternatives=("${@:2}")
    
    if apt-cache search "^${package}$" | grep -q "^${package}"; then
        echo -e "${GREEN}✓${NC} $package - Available"
        return 0
    else
        echo -e "${RED}✗${NC} $package - Not found"
        
        # Check alternatives
        for alt in "${alternatives[@]}"; do
            if apt-cache search "^${alt}$" | grep -q "^${alt}"; then
                echo -e "${YELLOW}  → Alternative found: $alt${NC}"
                return 0
            fi
        done
        
        echo -e "${YELLOW}  → No alternatives found${NC}"
        return 1
    fi
}

check_command() {
    local cmd=$1
    local package=$2
    
    if command -v "$cmd" &> /dev/null; then
        echo -e "${GREEN}✓${NC} $cmd - Available"
    else
        echo -e "${RED}✗${NC} $cmd - Not found (install: $package)"
    fi
}

print_header

echo "Checking Raspberry Pi OS version..."
OS_VERSION=$(lsb_release -cs 2>/dev/null || echo "unknown")
echo "OS: $(lsb_release -ds 2>/dev/null || echo "Unknown")"
echo "Codename: $OS_VERSION"
echo ""

echo "Checking core packages..."
apt update -qq

# Core development tools
echo "Core Development:"
check_package "git"
check_package "cmake"
check_package "build-essential"
echo ""

# Qt5 packages
echo "Qt5 Framework:"
check_package "qt5-default" "qt5-qmake" "qtbase5-dev"
check_package "qtbase5-dev"
check_package "qt5-qmake"
check_package "qtbase5-dev-tools"
check_package "qtmultimedia5-dev"
echo ""

# USB/Device support
echo "USB/Device Support:"
check_package "libusb-1.0.0-dev" "libusb-1.0-0-dev" "libusb-dev"
check_package "usbmuxd"
check_package "libimobiledevice6"
echo ""

# System libraries
echo "System Libraries:"
check_package "libboost-all-dev"
check_package "libssl-dev"
check_package "libprotobuf-dev"
check_package "protobuf-compiler"
echo ""

# Audio/Media
echo "Audio/Media:"
check_package "pulseaudio"
check_package "gstreamer1.0-plugins-base"
check_package "libgstreamer1.0-dev"
echo ""

# X Server
echo "X Server/Desktop:"
check_package "xorg"
check_package "xinit"
check_package "lightdm"
check_package "openbox"
echo ""

# Browsers
echo "Web Browsers:"
check_package "chromium-browser" "chromium" "firefox-esr"
check_package "chromium" "firefox-esr"
check_package "firefox-esr"
echo ""

# Check installed commands
echo "Available Commands:"
check_command "qmake" "qt5-qmake or qtbase5-dev"
check_command "cmake" "cmake"
check_command "git" "git"
check_command "chromium-browser" "chromium-browser"
check_command "chromium" "chromium"
check_command "firefox-esr" "firefox-esr"
echo ""

# Recommendations based on OS version
echo "Recommendations for your system:"
case $OS_VERSION in
    "bookworm"|"bullseye")
        echo -e "${BLUE}For Raspberry Pi OS Bookworm/Bullseye:${NC}"
        echo "• Use: qt5-qmake qtbase5-dev qtbase5-dev-tools"
        echo "• Use: libusb-1.0-0-dev (not libusb-1.0.0-dev)"
        echo "• Use: chromium (not chromium-browser)"
        ;;
    "buster")
        echo -e "${BLUE}For Raspberry Pi OS Buster:${NC}"
        echo "• Use: qt5-default (legacy package)"
        echo "• Use: libusb-1.0.0-dev"
        echo "• Use: chromium-browser"
        ;;
    *)
        echo -e "${YELLOW}Unknown OS version - trying modern package names${NC}"
        ;;
esac

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "To run installation with detected packages:"
echo "sudo ./install.sh"
echo ""
echo "To install packages manually, use the alternatives shown above."
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" 