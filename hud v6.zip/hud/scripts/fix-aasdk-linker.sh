#!/bin/bash

# AASDK Linker Error Fix Script
# Fixes "cannot find -l .../aasdk" and similar linker errors

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_header() {
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}    Android Auto HUD - AASDK Linker Fix${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   print_error "This script must be run as root (use sudo)"
   exit 1
fi

print_header

# Navigate to the project directory
cd /opt/android-auto-hud || {
    print_error "Project directory /opt/android-auto-hud not found"
    exit 1
}

# Check if OpenAuto directory exists
if [ ! -d "openauto" ]; then
    print_error "OpenAuto directory not found. Run the main installation first."
    exit 1
fi

cd openauto

# Diagnose AASDK build status
print_status "Diagnosing AASDK build status..."

if [ ! -d "aasdk" ]; then
    print_error "AASDK directory not found"
    print_status "Cloning AASDK manually..."
    git clone https://github.com/f1xpl/aasdk.git
fi

cd aasdk

# Check if AASDK is built
print_status "Checking AASDK build..."
if [ ! -d "build" ]; then
    print_warning "AASDK not built yet"
    BUILD_AASDK=true
else
    cd build
    # Check for library files
    if [ -f "libaasdk.a" ] || [ -f "lib/libaasdk.a" ] || [ -f "src/libaasdk.a" ]; then
        print_success "AASDK library found"
        AASDK_LIB_PATH=$(find . -name "libaasdk.a" | head -1)
        print_status "AASDK library at: $AASDK_LIB_PATH"
        BUILD_AASDK=false
    else
        print_warning "AASDK library not found in build directory"
        print_status "Contents of build directory:"
        ls -la
        BUILD_AASDK=true
    fi
    cd ..
fi

# Build AASDK if needed
if [ "$BUILD_AASDK" = true ]; then
    print_status "Building AASDK..."
    
    # Clean previous build
    rm -rf build
    mkdir -p build
    cd build
    
    # Install AASDK-specific dependencies
    print_status "Installing AASDK dependencies..."
    apt install -y \
        libboost-all-dev \
        libssl-dev \
        libprotobuf-dev \
        protobuf-compiler \
        libusb-1.0-0-dev \
        cmake \
        build-essential || {
        print_error "Failed to install AASDK dependencies"
        exit 1
    }
    
    # Configure AASDK build
    print_status "Configuring AASDK build..."
    if cmake \
        -DCMAKE_BUILD_TYPE=Release \
        -DCMAKE_CXX_STANDARD=14 \
        -DCMAKE_POSITION_INDEPENDENT_CODE=ON \
        ../; then
        
        print_status "Building AASDK library..."
        if make -j$(nproc --ignore=1); then
            print_success "AASDK built successfully"
        else
            print_error "AASDK build failed"
            print_status "Build error details:"
            cat CMakeFiles/CMakeError.log 2>/dev/null || echo "No CMake error log"
            exit 1
        fi
    else
        print_error "AASDK CMake configuration failed"
        exit 1
    fi
    
    cd ..
fi

# Verify AASDK library exists
print_status "Verifying AASDK library..."
cd build
AASDK_LIB_PATH=$(find . -name "libaasdk.a" | head -1)
if [ -n "$AASDK_LIB_PATH" ]; then
    print_success "AASDK library found at: $AASDK_LIB_PATH"
    FULL_AASDK_PATH="$(pwd)/$AASDK_LIB_PATH"
    print_status "Full path: $FULL_AASDK_PATH"
    
    # Check library info
    file "$FULL_AASDK_PATH"
    ls -la "$FULL_AASDK_PATH"
else
    print_error "AASDK library still not found after build"
    print_status "Contents of build directory:"
    find . -type f -name "*.a" | head -10
    find . -type f -name "*aasdk*" | head -10
    exit 1
fi

cd ../../

# Now rebuild OpenAuto with correct AASDK paths
print_status "Rebuilding OpenAuto with fixed AASDK paths..."

# Clean OpenAuto build
rm -rf build
mkdir -p build
cd build

# Get correct AASDK paths
AASDK_BUILD_DIR="$(pwd)/../aasdk/build"
AASDK_INCLUDE_DIR="$(pwd)/../aasdk/include"

# Find the actual library file
AASDK_LIB_FILE=$(find "$AASDK_BUILD_DIR" -name "libaasdk.a" | head -1)
if [ -z "$AASDK_LIB_FILE" ]; then
    print_error "Cannot find AASDK library file"
    exit 1
fi

AASDK_LIB_DIR=$(dirname "$AASDK_LIB_FILE")

print_status "Using AASDK paths:"
echo "  Include: $AASDK_INCLUDE_DIR"
echo "  Library Dir: $AASDK_LIB_DIR"
echo "  Library File: $AASDK_LIB_FILE"

# Configure OpenAuto with explicit library paths
print_status "Configuring OpenAuto build..."
if cmake \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_CXX_STANDARD=14 \
    -DRPI_BUILD=TRUE \
    -DAASDK_INCLUDE_DIRS="$AASDK_INCLUDE_DIR" \
    -DAASDK_LIBRARIES="$AASDK_LIB_DIR" \
    -DAASDK_PROTO_INCLUDE_DIRS="../aasdk" \
    -DAASDK_PROTO_LIBRARIES="$AASDK_LIB_DIR" \
    -DGST_BUILD=TRUE \
    -DQT_BUILD=TRUE \
    -DUSE_GST=TRUE \
    ../; then
    
    print_status "Building OpenAuto..."
    if make -j$(nproc --ignore=1); then
        print_success "OpenAuto built successfully!"
        
        # Verify the binary
        if [ -f "bin/autoapp" ]; then
            print_success "OpenAuto binary created: $(pwd)/bin/autoapp"
            
            # Update startup script
            print_status "Updating startup script..."
            sed -i "s|/opt/android-auto-hud/openauto/build/bin/autoapp|$(pwd)/bin/autoapp|g" /opt/android-auto-hud/start-hud.sh
            
            # Set permissions
            chown -R pi:pi /opt/android-auto-hud/openauto
            chmod +x "bin/autoapp"
            
            print_success "OpenAuto installation completed!"
        else
            print_warning "OpenAuto built but binary not found"
            ls -la bin/ || echo "No bin directory"
        fi
    else
        print_error "OpenAuto build failed"
        print_status "Checking for linker errors..."
        
        # Try to identify specific linker issues
        make VERBOSE=1 2>&1 | grep -E "(cannot find|undefined reference|ld:)" | head -10
        
        print_status "Installing fallback interface instead..."
        cd /opt/android-auto-hud
        rm -rf openauto
        
        # Create simple interface
        mkdir -p simple-auto
        cat > simple-auto/launcher.sh << 'EOF'
#!/bin/bash
export DISPLAY=:0
# Detect available browser
if command -v chromium-browser &> /dev/null; then
    BROWSER="chromium-browser"
elif command -v chromium &> /dev/null; then
    BROWSER="chromium"
elif command -v firefox-esr &> /dev/null; then
    BROWSER="firefox-esr"
else
    BROWSER="x-www-browser"
fi
# Simple Android Auto interface
$BROWSER --kiosk --disable-infobars \
    --disable-session-crashed-bubble \
    --disable-dev-shm-usage --no-sandbox \
    --window-size=800,480 \
    --autoplay-policy=no-user-gesture-required \
    "data:text/html,<html><head><title>Android Auto HUD</title></head><body style='margin:0;padding:20px;background:#1a1a1a;color:#fff;font-family:Arial;text-align:center;'><h1 style='color:#4CAF50;'>Android Auto HUD</h1><h2>Ready for Connection</h2><p>Connect your Android phone via USB</p><p>Enable USB Debugging in Developer Options</p><div style='margin:50px auto;padding:30px;border:2px solid #4CAF50;border-radius:10px;max-width:400px;'><h3>System Status</h3><p>✓ Display: DSI 5-inch (800x480)</p><p>✓ Rotation: 180° (Dashboard mount)</p><p>✓ Touch: Enabled</p><p>✓ Audio: 3.5mm jack</p></div><p style='margin-top:50px;font-size:14px;'>Linker error fixed - using simple interface</p></body></html>"
EOF
        chmod +x simple-auto/launcher.sh
        chown -R pi:pi simple-auto
        print_success "Simple interface installed as fallback"
    fi
else
    print_error "OpenAuto CMake configuration failed"
    exit 1
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
print_status "AASDK linker fix completed!"
echo ""
echo "If OpenAuto was built successfully:"
echo "  sudo systemctl restart android-auto-hud"
echo "  sudo ./scripts/android-auto-service.sh status"
echo ""
echo "To view logs:"
echo "  sudo ./scripts/android-auto-service.sh logs"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━" 