#!/bin/bash

# Android Auto Service Management Script
# Provides commands to start, stop, restart, and monitor the Android Auto HUD service

SERVICE_NAME="android-auto-hud"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
LOG_FILE="/var/log/android-auto-hud/service.log"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[SERVICE]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if service exists
check_service_exists() {
    if [ ! -f "$SERVICE_FILE" ]; then
        print_error "Service file not found: $SERVICE_FILE"
        print_status "Please run the installation script first"
        exit 1
    fi
}

# Function to get service status
get_service_status() {
    systemctl is-active "$SERVICE_NAME" 2>/dev/null
}

# Function to check if service is enabled
is_service_enabled() {
    systemctl is-enabled "$SERVICE_NAME" 2>/dev/null
}

# Function to start the service
start_service() {
    check_service_exists
    print_status "Starting Android Auto HUD service..."
    
    if systemctl start "$SERVICE_NAME"; then
        print_success "Service started successfully"
        sleep 2
        show_status
    else
        print_error "Failed to start service"
        show_logs
        exit 1
    fi
}

# Function to stop the service
stop_service() {
    check_service_exists
    print_status "Stopping Android Auto HUD service..."
    
    if systemctl stop "$SERVICE_NAME"; then
        print_success "Service stopped successfully"
    else
        print_error "Failed to stop service"
        exit 1
    fi
}

# Function to restart the service
restart_service() {
    check_service_exists
    print_status "Restarting Android Auto HUD service..."
    
    if systemctl restart "$SERVICE_NAME"; then
        print_success "Service restarted successfully"
        sleep 2
        show_status
    else
        print_error "Failed to restart service"
        show_logs
        exit 1
    fi
}

# Function to enable service for auto-start
enable_service() {
    check_service_exists
    print_status "Enabling Android Auto HUD service for auto-start..."
    
    if systemctl enable "$SERVICE_NAME"; then
        print_success "Service enabled for auto-start"
    else
        print_error "Failed to enable service"
        exit 1
    fi
}

# Function to disable service auto-start
disable_service() {
    check_service_exists
    print_status "Disabling Android Auto HUD service auto-start..."
    
    if systemctl disable "$SERVICE_NAME"; then
        print_success "Service auto-start disabled"
    else
        print_error "Failed to disable service"
        exit 1
    fi
}

# Function to show service status
show_status() {
    check_service_exists
    local status=$(get_service_status)
    local enabled=$(is_service_enabled)
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo -e "${BLUE}Android Auto HUD Service Status${NC}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    case $status in
        "active")
            print_success "Status: Running"
            ;;
        "inactive")
            print_warning "Status: Stopped"
            ;;
        "failed")
            print_error "Status: Failed"
            ;;
        *)
            print_warning "Status: Unknown ($status)"
            ;;
    esac
    
    case $enabled in
        "enabled")
            print_success "Auto-start: Enabled"
            ;;
        "disabled")
            print_warning "Auto-start: Disabled"
            ;;
        *)
            print_warning "Auto-start: Unknown ($enabled)"
            ;;
    esac
    
    echo ""
    
    # Show recent logs
    if [ "$status" = "active" ]; then
        print_status "Recent activity:"
        journalctl -u "$SERVICE_NAME" --no-pager --lines=3 --since="1 minute ago" | tail -3
    fi
    
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
}

# Function to show service logs
show_logs() {
    check_service_exists
    local lines=${1:-20}
    
    print_status "Showing last $lines lines of service logs..."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    if journalctl -u "$SERVICE_NAME" --no-pager --lines="$lines"; then
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    else
        print_error "Failed to retrieve logs"
    fi
}

# Function to follow logs in real-time
follow_logs() {
    check_service_exists
    print_status "Following service logs in real-time (Ctrl+C to stop)..."
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    
    journalctl -u "$SERVICE_NAME" -f
}

# Function to check system requirements
check_requirements() {
    print_status "Checking system requirements..."
    
    # Check if running on Raspberry Pi
    if grep -q "Raspberry Pi" /proc/cpuinfo; then
        print_success "Running on Raspberry Pi"
    else
        print_warning "Not running on Raspberry Pi"
    fi
    
    # Check display configuration
    if grep -q "display_rotate=2" /boot/config.txt; then
        print_success "Display rotation configured (180°)"
    else
        print_warning "Display rotation not configured"
    fi
    
    # Check if X server is running
    if pgrep -x "Xorg" > /dev/null; then
        print_success "X server is running"
    else
        print_warning "X server is not running"
    fi
    
    # Check USB devices
    local android_devices=$(lsusb | grep -E "(Google|Samsung|LG|Huawei|HTC|Sony|Motorola|OnePlus|Xiaomi)" | wc -l)
    if [ "$android_devices" -gt 0 ]; then
        print_success "Android device(s) detected: $android_devices"
    else
        print_warning "No Android devices detected"
    fi
}

# Function to show help
show_help() {
    echo "Android Auto HUD Service Management"
    echo ""
    echo "Usage: $0 <command> [options]"
    echo ""
    echo "Commands:"
    echo "  start        Start the service"
    echo "  stop         Stop the service"
    echo "  restart      Restart the service"
    echo "  status       Show service status"
    echo "  enable       Enable auto-start on boot"
    echo "  disable      Disable auto-start on boot"
    echo "  logs [n]     Show last n lines of logs (default: 20)"
    echo "  follow       Follow logs in real-time"
    echo "  check        Check system requirements"
    echo "  help         Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 start                    # Start the service"
    echo "  $0 logs 50                  # Show last 50 log lines"
    echo "  $0 status                   # Show current status"
}

# Main command processing
case "${1:-help}" in
    "start")
        start_service
        ;;
    "stop")
        stop_service
        ;;
    "restart")
        restart_service
        ;;
    "status")
        show_status
        ;;
    "enable")
        enable_service
        ;;
    "disable")
        disable_service
        ;;
    "logs")
        show_logs "${2:-20}"
        ;;
    "follow")
        follow_logs
        ;;
    "check")
        check_requirements
        ;;
    "help"|*)
        show_help
        ;;
esac 