#!/bin/bash

# Display Configuration Script for Android Auto HUD
# Handles display rotation, resolution, and other display settings

CONFIG_FILE="/boot/config.txt"
BACKUP_FILE="/boot/config.txt.backup"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[DISPLAY]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

# Create backup if it doesn't exist
if [ ! -f "$BACKUP_FILE" ]; then
    cp "$CONFIG_FILE" "$BACKUP_FILE"
    print_status "Created backup of config.txt"
fi

# Function to set display rotation
set_rotation() {
    local rotation=$1
    print_status "Setting display rotation to ${rotation}°..."
    
    # Remove existing rotation settings
    sed -i '/display_rotate=/d' "$CONFIG_FILE"
    sed -i '/lcd_rotate=/d' "$CONFIG_FILE"
    
    case $rotation in
        0)
            echo "display_rotate=0" >> "$CONFIG_FILE"
            ;;
        90)
            echo "display_rotate=1" >> "$CONFIG_FILE"
            ;;
        180)
            echo "display_rotate=2" >> "$CONFIG_FILE"
            ;;
        270)
            echo "display_rotate=3" >> "$CONFIG_FILE"
            ;;
        *)
            print_warning "Invalid rotation angle. Using 180°"
            echo "display_rotate=2" >> "$CONFIG_FILE"
            ;;
    esac
    
    print_success "Display rotation set to ${rotation}°"
}

# Function to configure GPU memory
configure_gpu_memory() {
    local memory=$1
    print_status "Configuring GPU memory to ${memory}MB..."
    
    # Remove existing gpu_mem settings
    sed -i '/gpu_mem=/d' "$CONFIG_FILE"
    
    echo "gpu_mem=$memory" >> "$CONFIG_FILE"
    print_success "GPU memory configured"
}

# Function to enable hardware acceleration
enable_hardware_acceleration() {
    print_status "Enabling hardware acceleration..."
    
    # Remove existing settings
    sed -i '/dtoverlay=vc4-kms-v3d/d' "$CONFIG_FILE"
    sed -i '/dtoverlay=vc4-fkms-v3d/d' "$CONFIG_FILE"
    
    # Add KMS overlay for Raspberry Pi 5
    echo "dtoverlay=vc4-kms-v3d" >> "$CONFIG_FILE"
    
    print_success "Hardware acceleration enabled"
}

# Function to configure DSI display settings
configure_dsi_display() {
    print_status "Configuring DSI 5-inch display connection..."
    
    # Remove any HDMI settings that might conflict
    sed -i '/hdmi_force_hotplug/d' "$CONFIG_FILE"
    sed -i '/hdmi_group/d' "$CONFIG_FILE"
    sed -i '/hdmi_mode/d' "$CONFIG_FILE"
    sed -i '/hdmi_cvt/d' "$CONFIG_FILE"
    
    # Configure for DSI display connection
    # Enable hardware acceleration for DSI
    if ! grep -q "dtoverlay=vc4-kms-v3d" "$CONFIG_FILE"; then
        echo "dtoverlay=vc4-kms-v3d" >> "$CONFIG_FILE"
    fi
    
    # Configure framebuffer for 800x480 DSI display
    if ! grep -q "framebuffer_width=800" "$CONFIG_FILE"; then
        echo "framebuffer_width=800" >> "$CONFIG_FILE"
    fi
    
    if ! grep -q "framebuffer_height=480" "$CONFIG_FILE"; then
        echo "framebuffer_height=480" >> "$CONFIG_FILE"
    fi
    
    # Disable overscan for DSI displays
    if ! grep -q "disable_overscan=1" "$CONFIG_FILE"; then
        echo "disable_overscan=1" >> "$CONFIG_FILE"
    fi
    
    # Enable DSI auto-detection
    if ! grep -q "display_auto_detect=1" "$CONFIG_FILE"; then
        echo "display_auto_detect=1" >> "$CONFIG_FILE"
    fi
    
    # Enable DSI auto-timing
    if ! grep -q "enable_dsi_auto_timing=1" "$CONFIG_FILE"; then
        echo "enable_dsi_auto_timing=1" >> "$CONFIG_FILE"
    fi
    
    print_success "DSI display settings configured"
}

# Function to configure touchscreen
configure_touchscreen() {
    print_status "Configuring touchscreen settings..."
    
    # Enable touch screen rotation to match display
    if ! grep -q "input_rotate=2" "$CONFIG_FILE"; then
        echo "input_rotate=2" >> "$CONFIG_FILE"
    fi
    
    print_success "Touchscreen configured"
}

# Main configuration function
configure_display() {
    print_status "Starting display configuration..."
    
    # Set 180° rotation (perfect for dashboard mounting)
    set_rotation 180
    
    # Configure GPU memory (128MB for good performance)
    configure_gpu_memory 128
    
    # Enable hardware acceleration
    enable_hardware_acceleration
    
    # Configure DSI display
    configure_dsi_display
    
    # Configure touchscreen
    configure_touchscreen
    
    print_success "Display configuration completed!"
    print_status "Please reboot to apply changes: sudo reboot"
}

# Command line options
case "${1:-configure}" in
    "rotate")
        set_rotation "${2:-180}"
        ;;
    "dsi")
        configure_dsi_display
        ;;
    "touchscreen")
        configure_touchscreen
        ;;
    "restore")
        if [ -f "$BACKUP_FILE" ]; then
            cp "$BACKUP_FILE" "$CONFIG_FILE"
            print_success "Configuration restored from backup"
        else
            print_warning "No backup file found"
        fi
        ;;
    "configure"|*)
        configure_display
        ;;
esac 